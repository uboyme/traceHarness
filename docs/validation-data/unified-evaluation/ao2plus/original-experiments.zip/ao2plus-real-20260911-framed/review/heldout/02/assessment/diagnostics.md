## Retrieval diagnostics

相关来源候选只定位来源容器；目录不等于正文。派发只证明内容进入请求，不证明模型已理解。
读取回执不证明正文已送达；完整有效搜索片段不需要额外 read。
负例按原查询、字段和分页范围审阅，不把查询无命中当成全库不存在。
observed=已出现，not_observed=本条轨迹未出现，unknown=未知，not_applicable=不适用。
pending_review=待人工审阅；provisional 匹配不是正式评分。

| 题目 ID | 相关来源候选 | 足够证据派发 | 回答评估 | 观测缺口 |
|---|---|---|---|---|
| mobile-specimen | observed | observed | passed | evidence-dispatched |
| restoration-room | observed | observed | failed | evidence-dispatched |
| stamp-catalog | not_applicable | not_applicable | passed | negative-scope-review |
| printshop-limit | observed | observed | passed | evidence-dispatched |
| geology-transfer | observed | observed | passed | evidence-dispatched |

```json
{
  "format": 1,
  "binding": {
    "run_id": "0a4c9dee-4acf-40fb-b78b-a1a9d434d7a4",
    "frozen_digest": "ebd286067600b93ba47cb40d7e303495b167b329bad23a42ebd073e698b87ba4",
    "evidence_digest": "2fecd11a31d4a13f7b8ad6b50b53fb0529008e622405456fc15feea1cf6fc0c6",
    "report_digest": "a176185c006426db7f40d8d0c63f5538043d4a1a6211ccec31c13cfc9ac7425c",
    "scorer_id": "retrieval-evidence-v1",
    "scorer_version": 1,
    "rubric_digest": "60da87b9426407b8fe5af8a016a1388838346ec9c58c13b462171a220108d3d0"
  },
  "analyzer": {
    "version": 1,
    "source_digest": "5b51bbe4ce7aadf42baf2c5cf7a1f6ed292c314ed5eedd67e07833fd3ef8d493"
  },
  "rows": [
    {
      "trial_id": "e5c9e54294f13a27126a6a1c10c3a032eb7e20bd296828f0c3a57e78973a91ad",
      "case_id": "mobile-specimen",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer states '根据提供的技能文档内容，流动标本车接收箱的封签必须打印 **LIME-274**。', which correctly extracts and presents the value 'LIME-274' from the dispatched evidence — specifically, the visible section body: '标本车接收箱的封签必须打印 LIME-274。'. This matches the expectation's source_text and required value. Attribution is implicit and valid ('根据提供的技能文档内容'), and no unsupported claims or scope violations are present. The evidence was actually dispatched (visible-source-excerpt, tier=section) and corresponds to the authoritative section 'required-procedure' of the 'mobile-specimen.manual' skill. The rubric requires correct value + attribution + dispatched evidence + no extra claims — all satisfied."
      },
      "provisional_answer_match": true,
      "question": "流动标本车的接收箱封签应打印哪个代号？",
      "answer": "根据提供的技能文档内容，流动标本车接收箱的封签必须打印 **LIME-274**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "d5704b04-c28c-4617-95f3-6b98c9e6f17f",
              "dispatch_fingerprint": "9c3b019b811fd34d067809b7682a97ec3c37d50dd0d460ce60689a80f266023a",
              "context_seq": 7,
              "id": "mobile-specimen.manual",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "mobile-specimen.manual"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "5e41ac6e-5f52-439b-b89a-8a3436672aef",
              "dispatch_fingerprint": "a024d3190716ab727cdfc483ef2156654e53e406e79503ca106a99cef2a3a5a3",
              "context_seq": 20,
              "id": "mobile-specimen.manual",
              "version": "1.0.0",
              "tier": "section",
              "provenance": {
                "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": "required-procedure",
                "skill_id": "mobile-specimen.manual"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "5e41ac6e-5f52-439b-b89a-8a3436672aef",
              "dispatch_fingerprint": "a024d3190716ab727cdfc483ef2156654e53e406e79503ca106a99cef2a3a5a3",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "mobile-specimen.manual",
                "provenance": {
                  "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
                  "chunk_id": null,
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": null,
                  "section_id": "required-procedure",
                  "skill_id": "mobile-specimen.manual"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "d5704b04-c28c-4617-95f3-6b98c9e6f17f",
            "dispatch_fingerprint": "9c3b019b811fd34d067809b7682a97ec3c37d50dd0d460ce60689a80f266023a",
            "context_seq": 7,
            "id": "mobile-specimen.manual",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "mobile-specimen.manual"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "5e41ac6e-5f52-439b-b89a-8a3436672aef",
            "dispatch_fingerprint": "a024d3190716ab727cdfc483ef2156654e53e406e79503ca106a99cef2a3a5a3",
            "context_seq": 20,
            "id": "mobile-specimen.manual",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "required-procedure",
              "skill_id": "mobile-specimen.manual"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_c8786c85b44b463c9603e7",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
              "chunk_id": null,
              "requested_tier": "section",
              "resource_id": null,
              "section_id": "required-procedure",
              "skill_id": "mobile-specimen.manual",
              "version": "1.0.0"
            },
            "requested_tier": "section",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "c179c03dbfa688cb04576e2f48e9af9ce49e83eea513480620d2d3e0a51a9d23",
      "case_id": "restoration-room",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "failed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer states both the口令 'RILL-682' and the action '按下蓝色隔离钮', but the expectation is strictly for the value 'RILL-682' (a code). The rubric requires positive answers to provide *correct value and attribution* with *no unsupported extra claims*. Including '蓝色隔离钮' exceeds the expected scope — it is not requested in the expectation (which specifies kind='value', value_type='code', value='RILL-682') and is unsupported by the expectation's source_text constraint (the expectation cites only the full sentence as context, but mandates extraction of *only* the code). The answer is over-specified and introduces an unrequested, unvalidated claim. Hence, it violates the rubric's requirement of 'no unsupported extra claims'."
      },
      "provisional_answer_match": true,
      "question": "古籍修复室遇到烘干柜异常时，要报什么口令并按哪个按钮？",
      "answer": "根据提供的古籍修复室工作手册内容，当遇到烘干柜异常时，值班员应报口令 **RILL-682**，并按下 **蓝色隔离钮**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "4701809e-d9ea-4cef-bf0d-ee466559762e",
              "dispatch_fingerprint": "304d596146f2c4c228caa53d22a59ab785a96b87b493405f6c8010775662b68c",
              "context_seq": 7,
              "id": "restoration-room.manual",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "restoration-room.manual"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "522043ff-3de2-4b5c-ae77-aef2746011a0",
              "dispatch_fingerprint": "92956f78580d23dbd8e18420505c9b825715558becbb47764b96935baafde4e1",
              "context_seq": 20,
              "id": "restoration-room.manual",
              "version": "1.0.0",
              "tier": "chunk",
              "provenance": {
                "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
                "chunk_id": "procedure",
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": "response-card",
                "section_id": null,
                "skill_id": "restoration-room.manual"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "522043ff-3de2-4b5c-ae77-aef2746011a0",
              "dispatch_fingerprint": "92956f78580d23dbd8e18420505c9b825715558becbb47764b96935baafde4e1",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "restoration-room.manual",
                "provenance": {
                  "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
                  "chunk_id": "procedure",
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": "response-card",
                  "section_id": null,
                  "skill_id": "restoration-room.manual"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "4701809e-d9ea-4cef-bf0d-ee466559762e",
            "dispatch_fingerprint": "304d596146f2c4c228caa53d22a59ab785a96b87b493405f6c8010775662b68c",
            "context_seq": 7,
            "id": "restoration-room.manual",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "restoration-room.manual"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "522043ff-3de2-4b5c-ae77-aef2746011a0",
            "dispatch_fingerprint": "92956f78580d23dbd8e18420505c9b825715558becbb47764b96935baafde4e1",
            "context_seq": 20,
            "id": "restoration-room.manual",
            "version": "1.0.0",
            "tier": "chunk",
            "provenance": {
              "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
              "chunk_id": "procedure",
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": "response-card",
              "section_id": null,
              "skill_id": "restoration-room.manual"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_ca3797579b544922ae9f8c",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
              "chunk_id": "procedure",
              "requested_tier": "chunk",
              "resource_id": "response-card",
              "section_id": null,
              "skill_id": "restoration-room.manual",
              "version": "1.0.0"
            },
            "requested_tier": "chunk",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "720e30d75a0b9ad2a5c7969dd9c9a91a05262307f71988808397d6ddda3153fc",
      "case_id": "stamp-catalog",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer correctly states that the visible evidence — a `directory`-tier Skill navigation for `stamp-catalog.manual` — contains only metadata (titles, summaries, section IDs, byte counts) and no content mentioning '停车券' or pricing. It accurately reports the observed structure: one required-procedure section and ten routine sections, all with identical summary '清洁记录' and titles '清洁登记 X', none referencing parking vouchers or money. The overall `summary` ('邮票目录整理规范操作说明。') is correctly cited and thematically irrelevant to parking vouchers. The conclusion '没有写停车券多少钱' is scoped precisely to the *provided directory navigation*, not an unsupported claim about the full document's contents — and the `evidence_scope` explicitly confirms `extent: \"navigation-metadata-only\"`. This satisfies the rubric’s requirement for negative answers: no overstatement of absence beyond the actually examined scope, no invented values, and full attribution to the visible navigation metadata. No further search or read was needed or claimed."
      },
      "provisional_answer_match": null,
      "question": "邮票目录整理规范里写了停车券多少钱吗？",
      "answer": "邮票目录整理规范（`stamp-catalog.manual`）的目录结构（当前参考中提供的 `directory` 导航）仅包含以下部分：\n\n- “条目登记”（required-procedure）\n- 10 个“清洁登记”例行章节（routine-0 至 routine-9）\n\n所有 section 的 `summary` 均为“清洁记录”，`title` 均为“清洁登记 X”，且无一提及“停车券”或价格相关内容。`summary` 和 `title` 中均未出现“停车券”“停车”“券”“价格”“元”“钱”等关键词。\n\n该 Skill 文档的总体 `summary` 是：“邮票目录整理规范操作说明。”，主题明确限定于邮票目录整理，与停车券无关。\n\n因此，**邮票目录整理规范里没有写停车券多少钱**。\n\n答案：否。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "not_applicable",
          "granularity": "source-container",
          "observations": []
        },
        "evidence": {
          "status": "not_applicable",
          "observations": []
        },
        "gap": "negative-scope-review",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "87c766db-e7ea-4e6d-b2df-422c517de277",
            "dispatch_fingerprint": "3829c775e034abb1453c08db5babb69986511e20130d445e8b8d0e3d5a1b7090",
            "context_seq": 7,
            "id": "stamp-catalog.manual",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "aba7e659d754c4819f49fdead1ccdc52b213bfa125e46e731689e0afd3493f2e",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "stamp-catalog.manual"
            }
          }
        ],
        "read_requests": [],
        "search_coverage": [],
        "negative_scope_review_required": true,
        "successful_answer_dispatches": 1,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "40d20b9de8b881c07666bf9b66d47dd1373dba9be07addaf272617ff2b18c06a",
      "case_id": "printshop-limit",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer '共享印制车间批准的同时入场人数是 27 人。' correctly states the value (27) and matches the source_text in expectation. The dispatched_evidence includes a section-tier memory body '共享印制车间获批的同时入场上限为 27 人。', which is authoritative (approved), visible in visible_evidence, and contains the exact numeric value 27. The answer is complete, attributed to the correct memory_id ('printshop.capacity'), makes no unsupported claims, and stays within the scope of the evidence (a single approved section excerpt). The rubric requires correct value and attribution with evidence actually dispatched before answering — both are satisfied."
      },
      "provisional_answer_match": true,
      "question": "共享印制车间批准的同时入场人数是多少？",
      "answer": "共享印制车间批准的同时入场人数是 27 人。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "7a696fbe-8489-4a53-a8ca-406d221c5f61",
              "dispatch_fingerprint": "5340067b68e16ac816b0639cfd2f60e3445a2ba79e2a6c95d540328dda3712b1",
              "context_seq": 7,
              "id": "printshop.capacity",
              "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
              "tier": "directory",
              "provenance": {
                "activation_ref": {
                  "digest": "fa17f7fb51f2e8d8f1635f7286ea836fc98eafd9d24ce10d116b5dcf293e2d57",
                  "event_id": "62c460a7-1bee-4244-aa76-9fcbe32d5811",
                  "seq": 2,
                  "stream_id": "memory:printshop",
                  "type": "memory/approved"
                },
                "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
                "fact_slot": "capacity",
                "memory_id": "printshop.capacity",
                "project_id": "printshop"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "a62d7767-57cf-45e1-aad7-4b1a0eb32a0e",
              "dispatch_fingerprint": "2c86cbc3271ae1f48b339a2b96dc22543bb9a8a393300e149efb93cbdf969b50",
              "context_seq": 20,
              "id": "printshop.capacity",
              "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
              "tier": "section",
              "provenance": {
                "activation_ref": {
                  "digest": "fa17f7fb51f2e8d8f1635f7286ea836fc98eafd9d24ce10d116b5dcf293e2d57",
                  "event_id": "62c460a7-1bee-4244-aa76-9fcbe32d5811",
                  "seq": 2,
                  "stream_id": "memory:printshop",
                  "type": "memory/approved"
                },
                "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
                "fact_slot": "capacity",
                "memory_id": "printshop.capacity",
                "project_id": "printshop"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "a62d7767-57cf-45e1-aad7-4b1a0eb32a0e",
              "dispatch_fingerprint": "2c86cbc3271ae1f48b339a2b96dc22543bb9a8a393300e149efb93cbdf969b50",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "printshop.capacity",
                "provenance": {
                  "activation_ref": {
                    "digest": "fa17f7fb51f2e8d8f1635f7286ea836fc98eafd9d24ce10d116b5dcf293e2d57",
                    "event_id": "62c460a7-1bee-4244-aa76-9fcbe32d5811",
                    "seq": 2,
                    "stream_id": "memory:printshop",
                    "type": "memory/approved"
                  },
                  "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
                  "fact_slot": "capacity",
                  "memory_id": "printshop.capacity",
                  "project_id": "printshop"
                },
                "source_refs": [
                  {
                    "digest": "8998ce5ec9810d8b70e29613e4455298cb965e5f05c603bac7f6404cd7f2488b",
                    "event_id": "7057ad12-8a30-4063-90f4-d2f80ae4d532",
                    "seq": 1,
                    "stream_id": "memory:printshop",
                    "type": "memory/proposed"
                  },
                  {
                    "digest": "fa17f7fb51f2e8d8f1635f7286ea836fc98eafd9d24ce10d116b5dcf293e2d57",
                    "event_id": "62c460a7-1bee-4244-aa76-9fcbe32d5811",
                    "seq": 2,
                    "stream_id": "memory:printshop",
                    "type": "memory/approved"
                  }
                ],
                "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "7a696fbe-8489-4a53-a8ca-406d221c5f61",
            "dispatch_fingerprint": "5340067b68e16ac816b0639cfd2f60e3445a2ba79e2a6c95d540328dda3712b1",
            "context_seq": 7,
            "id": "printshop.capacity",
            "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
            "tier": "directory",
            "provenance": {
              "activation_ref": {
                "digest": "fa17f7fb51f2e8d8f1635f7286ea836fc98eafd9d24ce10d116b5dcf293e2d57",
                "event_id": "62c460a7-1bee-4244-aa76-9fcbe32d5811",
                "seq": 2,
                "stream_id": "memory:printshop",
                "type": "memory/approved"
              },
              "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
              "fact_slot": "capacity",
              "memory_id": "printshop.capacity",
              "project_id": "printshop"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "a62d7767-57cf-45e1-aad7-4b1a0eb32a0e",
            "dispatch_fingerprint": "2c86cbc3271ae1f48b339a2b96dc22543bb9a8a393300e149efb93cbdf969b50",
            "context_seq": 20,
            "id": "printshop.capacity",
            "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
            "tier": "section",
            "provenance": {
              "activation_ref": {
                "digest": "fa17f7fb51f2e8d8f1635f7286ea836fc98eafd9d24ce10d116b5dcf293e2d57",
                "event_id": "62c460a7-1bee-4244-aa76-9fcbe32d5811",
                "seq": 2,
                "stream_id": "memory:printshop",
                "type": "memory/approved"
              },
              "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
              "fact_slot": "capacity",
              "memory_id": "printshop.capacity",
              "project_id": "printshop"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_89523c29b80f43c28eb6ef",
            "tool_name": "request_workspace_memory",
            "arguments": {
              "memory_id": "printshop.capacity",
              "requested_tier": "section",
              "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6"
            },
            "requested_tier": "section",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "d431fd99ab910f9144b58749f0e3b049b2b67dd8531323f03d52e255165c2eec",
      "case_id": "geology-transfer",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer states '根据历史记录，临时地质展的提交批次标志为 **KITE-905**，交接点设在 **西拱门第二排**。' This is fully supported by the visible evidence: the 'visible_evidence' includes a history chunk with body containing exactly the string '临时地质展的新提交批次标志为 KITE-905，交接点设在西拱门第二排。', and the expectation specifies that the correct value is 'KITE-905' (a code), which matches. The answer correctly attributes the information to '历史记录' (history), and no unsupported claims are made. The dispatched evidence confirms the history page was successfully read (request_history_page succeeded), and the excerpt contains the exact source text cited in the expectation. All rubric requirements for a positive answer — correct value, proper attribution, evidence dispatched and visible before answering, no extra unsupported claims — are satisfied."
      },
      "provisional_answer_match": true,
      "question": "之前临时地质展说的提交批次标志和交接点是什么？",
      "answer": "根据历史记录，临时地质展的提交批次标志为 **KITE-905**，交接点设在 **西拱门第二排**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 56,
              "attempt_id": "97bb2f92-49e8-46c3-8129-8d3e029ce222",
              "dispatch_fingerprint": "cc8774104c07a45817b4ea6704bd46b47bef9b08c17bf80cd49fba51360e0516",
              "context_seq": 53,
              "id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
              "version": "4850898cb8d2530bfbd78967f923a91ca71cd47e504db37919a2f1cda81cfea7",
              "tier": "directory",
              "provenance": {
                "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                "freshness": "unknown",
                "observed_at": "2026-09-10T18:38:03.376853+00:00",
                "observed_through_seq": 46,
                "page": null,
                "request_ref": null,
                "workspace_observation": null
              }
            },
            {
              "request_snapshot_seq": 69,
              "attempt_id": "e6f93f02-0325-496b-81da-09ae2baa5194",
              "dispatch_fingerprint": "5624ea31d88c7975575b982b15f10ef5367d9874caebc69e69d12beecc536e74",
              "context_seq": 66,
              "id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
              "version": "4850898cb8d2530bfbd78967f923a91ca71cd47e504db37919a2f1cda81cfea7",
              "tier": "chunk",
              "provenance": {
                "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                "freshness": "unknown",
                "observed_at": "2026-09-10T18:38:03.376853+00:00",
                "observed_through_seq": 46,
                "page": {
                  "index": 0,
                  "leaf_refs": [
                    {
                      "digest": "1e5da7e118321b7ab2ecbed79bb0059b3399dfca9d824d84781c36136dc054ac",
                      "event_id": "3da597ce-3877-46ee-bff1-82481107fb7e",
                      "seq": 6,
                      "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                      "type": "user/message"
                    },
                    {
                      "digest": "26e9fd8742075a5ace425b3630baf3490d3a30261dbd44593f4e0c4a3bffb4af",
                      "event_id": "5dbd2a73-7a32-4e10-9a1e-3c25e4ed6cf8",
                      "seq": 13,
                      "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                      "type": "assistant/message"
                    },
                    {
                      "digest": "895d4d8ab609b8b98f1dc6cdbdc1d43a8eeb577e2200bdac4bbc0609f873296a",
                      "event_id": "0f742926-b56b-4cf0-9fa0-2562e58bef16",
                      "seq": 21,
                      "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                      "type": "user/message"
                    },
                    {
                      "digest": "bea6250c08f2e56ed4cad0f8b6b514f2b3a76e19a9d31ece887cae1247929d4f",
                      "event_id": "d0a95914-b681-416a-9e7d-0b1f9636d79d",
                      "seq": 28,
                      "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                      "type": "assistant/message"
                    }
                  ],
                  "next_cursor": {
                    "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                    "index": 1,
                    "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
                  },
                  "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
                },
                "request_ref": {
                  "digest": "7c772d3353fa74d921bb52a5c11ff4bfc0c20e39b9e63fb345d93485c9933f51",
                  "event_id": "aaa8f5a7-14fd-41ca-8ef4-7a703ee55e90",
                  "seq": 63,
                  "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                  "type": "tool/result"
                },
                "workspace_observation": null
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 69,
              "attempt_id": "e6f93f02-0325-496b-81da-09ae2baa5194",
              "dispatch_fingerprint": "5624ea31d88c7975575b982b15f10ef5367d9874caebc69e69d12beecc536e74",
              "context_seq": 66,
              "tool_result_seq": null,
              "reference": {
                "id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                "provenance": {
                  "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                  "freshness": "unknown",
                  "observed_at": "2026-09-10T18:38:03.376853+00:00",
                  "observed_through_seq": 46,
                  "page": {
                    "index": 0,
                    "leaf_refs": [
                      {
                        "digest": "1e5da7e118321b7ab2ecbed79bb0059b3399dfca9d824d84781c36136dc054ac",
                        "event_id": "3da597ce-3877-46ee-bff1-82481107fb7e",
                        "seq": 6,
                        "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                        "type": "user/message"
                      },
                      {
                        "digest": "26e9fd8742075a5ace425b3630baf3490d3a30261dbd44593f4e0c4a3bffb4af",
                        "event_id": "5dbd2a73-7a32-4e10-9a1e-3c25e4ed6cf8",
                        "seq": 13,
                        "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                        "type": "assistant/message"
                      },
                      {
                        "digest": "895d4d8ab609b8b98f1dc6cdbdc1d43a8eeb577e2200bdac4bbc0609f873296a",
                        "event_id": "0f742926-b56b-4cf0-9fa0-2562e58bef16",
                        "seq": 21,
                        "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                        "type": "user/message"
                      },
                      {
                        "digest": "bea6250c08f2e56ed4cad0f8b6b514f2b3a76e19a9d31ece887cae1247929d4f",
                        "event_id": "d0a95914-b681-416a-9e7d-0b1f9636d79d",
                        "seq": 28,
                        "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                        "type": "assistant/message"
                      }
                    ],
                    "next_cursor": {
                      "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                      "index": 1,
                      "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
                    },
                    "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
                  },
                  "request_ref": {
                    "digest": "7c772d3353fa74d921bb52a5c11ff4bfc0c20e39b9e63fb345d93485c9933f51",
                    "event_id": "aaa8f5a7-14fd-41ca-8ef4-7a703ee55e90",
                    "seq": 63,
                    "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                    "type": "tool/result"
                  },
                  "workspace_observation": null
                },
                "source_refs": [
                  {
                    "digest": "4850898cb8d2530bfbd78967f923a91ca71cd47e504db37919a2f1cda81cfea7",
                    "event_id": "bb8369f2-6610-4aa7-ac73-0a3c4ca74543",
                    "seq": 47,
                    "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                    "type": "surface/replace"
                  },
                  {
                    "digest": "f49993f79538c2338f765861bb7351c0240be5684533f60ad9757ccf40c054b6",
                    "event_id": "25d45fd9-af81-4c93-9506-b3874d3c4eaa",
                    "seq": 46,
                    "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                    "type": "turn/end"
                  }
                ],
                "version": "4850898cb8d2530bfbd78967f923a91ca71cd47e504db37919a2f1cda81cfea7"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 56,
            "attempt_id": "97bb2f92-49e8-46c3-8129-8d3e029ce222",
            "dispatch_fingerprint": "cc8774104c07a45817b4ea6704bd46b47bef9b08c17bf80cd49fba51360e0516",
            "context_seq": 53,
            "id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
            "version": "4850898cb8d2530bfbd78967f923a91ca71cd47e504db37919a2f1cda81cfea7",
            "tier": "directory",
            "provenance": {
              "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
              "freshness": "unknown",
              "observed_at": "2026-09-10T18:38:03.376853+00:00",
              "observed_through_seq": 46,
              "page": null,
              "request_ref": null,
              "workspace_observation": null
            }
          },
          {
            "request_snapshot_seq": 69,
            "attempt_id": "e6f93f02-0325-496b-81da-09ae2baa5194",
            "dispatch_fingerprint": "5624ea31d88c7975575b982b15f10ef5367d9874caebc69e69d12beecc536e74",
            "context_seq": 66,
            "id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
            "version": "4850898cb8d2530bfbd78967f923a91ca71cd47e504db37919a2f1cda81cfea7",
            "tier": "chunk",
            "provenance": {
              "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
              "freshness": "unknown",
              "observed_at": "2026-09-10T18:38:03.376853+00:00",
              "observed_through_seq": 46,
              "page": {
                "index": 0,
                "leaf_refs": [
                  {
                    "digest": "1e5da7e118321b7ab2ecbed79bb0059b3399dfca9d824d84781c36136dc054ac",
                    "event_id": "3da597ce-3877-46ee-bff1-82481107fb7e",
                    "seq": 6,
                    "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                    "type": "user/message"
                  },
                  {
                    "digest": "26e9fd8742075a5ace425b3630baf3490d3a30261dbd44593f4e0c4a3bffb4af",
                    "event_id": "5dbd2a73-7a32-4e10-9a1e-3c25e4ed6cf8",
                    "seq": 13,
                    "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                    "type": "assistant/message"
                  },
                  {
                    "digest": "895d4d8ab609b8b98f1dc6cdbdc1d43a8eeb577e2200bdac4bbc0609f873296a",
                    "event_id": "0f742926-b56b-4cf0-9fa0-2562e58bef16",
                    "seq": 21,
                    "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                    "type": "user/message"
                  },
                  {
                    "digest": "bea6250c08f2e56ed4cad0f8b6b514f2b3a76e19a9d31ece887cae1247929d4f",
                    "event_id": "d0a95914-b681-416a-9e7d-0b1f9636d79d",
                    "seq": 28,
                    "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                    "type": "assistant/message"
                  }
                ],
                "next_cursor": {
                  "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                  "index": 1,
                  "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
                },
                "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
              },
              "request_ref": {
                "digest": "7c772d3353fa74d921bb52a5c11ff4bfc0c20e39b9e63fb345d93485c9933f51",
                "event_id": "aaa8f5a7-14fd-41ca-8ef4-7a703ee55e90",
                "seq": 63,
                "stream_id": "session:4b64cb1b-6322-4df7-84f7-94a0e56826fe",
                "type": "tool/result"
              },
              "workspace_observation": null
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 61,
            "tool_call_id": "call_d9e4c2df76114d2d9a61f4",
            "tool_name": "request_history_page",
            "arguments": {
              "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
              "cursor": {
                "block_id": "5fc0fffcc7b0d47642a1ceef25475adc6bf59ba291fa6a2a3817d76485c02592",
                "index": 0,
                "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
              },
              "requested_tier": "chunk"
            },
            "requested_tier": "chunk",
            "result_seq": 63,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    }
  ]
}
```
