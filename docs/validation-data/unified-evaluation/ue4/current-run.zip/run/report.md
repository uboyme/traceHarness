# Evaluation: retrieval-episodes-development-v1

Run: cf68e597-0326-4e00-a804-b1a7a5c6c134
Task type: retrieval_episode
Measurement complete: True
Assessment complete: False

| Trial | Execution | Assessment | Convergence |
|---|---|---|---|
| d7e31699017eb2eca9d67ca083c83f5bca06d410091f56b7646093f3a8665916 | completed | pending_review | converged |
| 5e30f912a58ec75006b97b38e9470051a529a1de82858fc5d70be9e508556f01 | completed | pending_review | converged |
| 0c87c300e3a47171fca7095f6bb8b0c9ed76456c01295ab649274cdc47443f22 | completed | pending_review | converged |
| c788aa8763afc904b92924c847c40394655bd05a028234d332834432d7f409a2 | completed | pending_review | converged |
| 1ae3d8eea05beb1a156ac32bbd340039cf980ebb2a65bbc29437fd692879fc8f | completed | pending_review | converged |
| 1196f324874b6626865e3f906f07590a28ee38dff80f70fd9f89a0d80f0c0e31 | completed | pending_review | converged |
| b176782cf4c577473894ff0fa75df32b87c48a19e81722261a87c9394ae3cf5b | completed | pending_review | converged |
| a9f3752b881293679354cf2397fd084ebe5841d0729030709d594d48280ca91a | completed | pending_review | converged |
| a045178d3485d212c3e90686b9f9edd680f05d82b51e26791a232cfd6f65d2ba | completed | pending_review | converged |
| 95a9d7702b9f1bad8b497b9a7f17efa122f3296a65bc409d7b16cd494285750a | completed | pending_review | converged |
| 8aa15000b29884384bcbf8feb20388d3eb37163af2f28224cc1f148d92833ea9 | completed | pending_review | converged |
| d900650956c788b7937a9d20adfbb9c40137eaec001d88a77a31c433db4dc1ec | completed | pending_review | converged |
| e1df8c507cf389b9407fb7717ab56c6af8c7e92f563594baf07bf9bd1d56de77 | completed | pending_review | converged |
| 5cbfdd048570215a870ce27dedd01626fbaa59c01b3a39209180e55ff85799f4 | completed | pending_review | converged |
| 7af665a50ceb9b3a868513d80938d60f11418267975a006440a24af94795ecfd | completed | pending_review | converged |
| 2a41a5425f9a0f2f3f5bf683abbbe3bccb578c8ce7307a108366c8b6fab04e9b | completed | pending_review | converged |
| 70cc5cfedbef89bf0123e6e4104638cc21402269c0440519d56cb3c200e32204 | completed | pending_review | converged |
| 083555aee88165241ae92c88aa1496ed0ef89c4d51b9ad6e5bf87fbd8d354ad3 | completed | pending_review | converged |
| 6c48ffbbfd0b7602ed831bbbb9460a8164df7451df716fd38430314e550eb792 | completed | pending_review | converged |
| 6e3a5ebf46e0f32273abca7bfca5d763ea940304e5c3ac9edfb26f2ee2555094 | completed | pending_review | converged |
| cbcbdd31ecf9799b92a0f51d5989d1e0e08d182ac03bc15e62fe23c131ffcb32 | completed | pending_review | converged |
| 1d05d79c4ef65814e92d24052fcad6217be844683bd73676212c3c2c8432819c | completed | pending_review | converged |
| a658fa414d9100c281158272d07881485306b7619272b58d15543cd9123d849b | completed | pending_review | converged |
| 5df71187593cc575805a676e04897bd22870e5b9b0c3011b539e793ec0137ff8 | completed | pending_review | converged |
| 8c3e21198674db91bacb7e6fa7bfb10fcf457033294ec803f3347693014881c2 | completed | pending_review | converged |
| 63d30afe91e31f9c64e63d8210fbcd61ce4d7a136f29dd3c29112f56824c06e4 | completed | pending_review | converged |
| 87be3fb5f48d77bb6a0e5cb4bb975c16216e345bc27090cbbd0c5eddd1d0e3fa | completed | pending_review | converged |
| 8dc369c257a7d2e70f7dbf3b1f442222d87c9434df3fda770a8b057df635a913 | completed | pending_review | converged |
| 74c480ac4fdfac5d5f30a532f6cf98cd39feabeeda93ac77decb70a2342c99a3 | completed | pending_review | converged |
| 36cd52b02b587a6565ab7520622a4ca68cbff99ed1a5a1c9c11a45cdf4ce0594 | completed | pending_review | converged |
| b496d552e35c444f6f897fcba9a914b8bb8eb16ec7b704e633f97dfc2498b03a | completed | pending_review | converged |
| ffb0d9a76b24c201cef45b5fdf382bef8e277dd15adbb17aa70e84bc674a3e48 | completed | pending_review | converged |
| 0f1ba72dbef69df0ea4b4fd7f3ff1f5fb9f246962f7000511e18434258f71a5f | completed | pending_review | converged |
| ffc19b9d12e73fa4f8a576496befac4eaefaa48f4b8cf4ffccf83be792f6a450 | completed | pending_review | converged |
| 95735c4fbdf82ec62630314d41e174b0778abd17a160cb34e2ede3ebbfb19ced | completed | pending_review | converged |
| 596b6696e62ab5aa4e49e0244dba4d55db244ce9a6475b8549417ab53296d6c1 | completed | pending_review | converged |
| a3a8cba749626491ef6be94f7ca32e6cd6aab918274307ffc0d1ed3eaa9b7613 | completed | pending_review | converged |
| ef52da1337491aa97738399582d2b0d9c16c767cb8299f20cad35b5c04e90ce0 | completed | pending_review | converged |
| de9cb7b1b5fb9c623c57cdadc93c4c7fa6b7f971094808d63cd197837fdc7102 | completed | pending_review | converged |
| d9cb523acbcb24139bf9ede904d917453609ded07539c2a0aea3b73a11c65354 | completed | pending_review | converged |
| 824bfc025b571ecef9d260f1988ad75e3517a5686fbc70c8cac2a4997e8c6523 | completed | pending_review | converged |
| 2f29b6ee31c1a2eec3fd8efc6830b5a5c4dab9c571d25b8272a0529b65a9dee2 | completed | pending_review | converged |
| 2c8eaad62a4446c5f8dc87fb28573be53f7aa2aea548142a04d7768deba2484e | completed | pending_review | converged |
| c3ebe3437f6f01770f311d8fd8e4b911bc43b327e4e8738d57265df5b01c9238 | completed | pending_review | converged |
| 3a52f88306fbe8a9778db361fedd7ddde8d91c46f32c840bdac26a2889a3cdbc | completed | pending_review | converged |
| 460748e9a5a77d805131d90686a2c4e2dbe70b4f9b5afcb510cd3599342b7c8d | completed | pending_review | converged |
| a9c43895282a36fa515567d7fc271b9e7e2d70b98181058eb8abf97d94fbf006 | completed | pending_review | converged |
| b6b6b7459f1f97080bcb0c3b28a6a576b79041510cd97eb1755a1cb4000836ac | completed | pending_review | converged |
| 6137333672aab690c7ee98d017a4b723f5e2afdd36d1e61df634de2994293396 | completed | pending_review | converged |
| 27dcb3051acb22d8b0744c57f71909472f4932b5fad6034ebec73075ec62e201 | completed | pending_review | converged |
| 08504f43eaa09065fcfc2cf180b5f4c6b15ac3e70989418ba4303f673c860451 | completed | pending_review | converged |
| 81ea55202cfaf49425df69b19770ba4eb7e454929ed7eaddbd5b2d76452d9c84 | completed | pending_review | converged |
| 380d7de86db1b016743763fc602f041b512575f953aa72c3be5480859e6af2ba | completed | pending_review | converged |
| 9ca668ed0568211adc48ba677e4c4871e323e3b31fd3eaec7b494570b05b1ada | completed | pending_review | converged |
| d42e232d7c807bb1c341aebdcfec6fa331e81ff7efff0bb50a27724e8fa14637 | completed | pending_review | converged |
| 503abc07e48fb375244ee3f076f03f86b86fc13cd8023098ec5e068dd629a4e1 | completed | pending_review | converged |
| 03d510c07eba5b7f5642c81f8078cc0550e6c5e3d3288985a1d400838d17fd8a | completed | pending_review | converged |
| 7c4f858ce6cfbce5df812cd5f39f15cae9a71e352c9a4eca1efe0fa484c81da9 | completed | pending_review | converged |
| c19d3cc5909c50556146a98cf05540b5cfef900ad4e4cb5a5118096c504ab45c | completed | pending_review | converged |
| 08e2d94fd7cc9f83372747895c76100ef58c0d3aa925724677a6874a38c1e2b2 | completed | pending_review | converged |
| 092556a95bbb41b8cf201abeec0aec0cb76fc4d482367227f071edd8b1cbe5d0 | completed | pending_review | converged |
| 89a01368eb8deffb9dc5ccc60851293dac5bf8a1575512aab2e51aeb1a9e006a | completed | pending_review | converged |
| 5f007cda2ad27b45529418fd4137bfd0f772c9c322a53d9901041da9d872e4ef | completed | pending_review | converged |
| f7686c58130eeaf3c2be801edeb4e01912a872193de695da78dd0d2e90a73e79 | completed | pending_review | converged |
| 0b6d07521747bfe39018826fc03f23af8337d7b09f88ccef2ef40701ec009bed | completed | pending_review | converged |
| 391e329f66f09372c766c82ab5111ccdf437f1909ac85f732866ab9c967c9b75 | completed | pending_review | converged |
| 682d5f4b90706a3d32413e53300c0bfa6b85ee4feae687911c68aca56e0f649e | completed | pending_review | converged |
| e262b716071438547cb1ae6ae1c5098c22e31e1156743d7277d1ef8d3509ca5d | completed | pending_review | converged |
| a713e1e5e4ffc6bde1179758189c5e6fe8c5b64a968c8146bb8fda061c4177be | completed | pending_review | converged |
| c4cf41fea890ab15bd004e314a0e3b0ba52f8b3f1f424b4d836895a757b8d0fc | completed | pending_review | converged |
| 638c338072bb40eaa99cdbbe375078517e74c404ece602af49bd74254ade714b | completed | pending_review | converged |
| b0822790de97393f8e131b08c73825947dde8594ef3c7f8eebf3282fc2bcbf12 | completed | pending_review | converged |

## Retrieval episodes

Measured: 72/72. Exact answer matches are provisional; final judgments require evidence review.

## Retrieval diagnostics

相关来源候选只定位来源容器；目录不等于正文。派发只证明内容进入请求，不证明模型已理解。
读取回执不证明正文已送达；完整有效搜索片段不需要额外 read。
负例按原查询、字段和分页范围审阅，不把查询无命中当成全库不存在。
observed=已出现，not_observed=本条轨迹未出现，unknown=未知，not_applicable=不适用。
pending_review=待人工审阅；provisional 匹配不是正式评分。

| 题目 ID | 相关来源候选 | 足够证据派发 | 回答评估 | 观测缺口 |
|---|---|---|---|---|
| h-direct | observed | observed | pending_review | evidence-dispatched |
| h-rephrase | observed | observed | pending_review | evidence-dispatched |
| h-late-page | observed | observed | pending_review | evidence-dispatched |
| h-disambiguate | observed | observed | pending_review | evidence-dispatched |
| h-english | observed | observed | pending_review | evidence-dispatched |
| h-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| s-direct | observed | observed | pending_review | evidence-dispatched |
| s-rephrase | observed | observed | pending_review | evidence-dispatched |
| s-large-directory | observed | observed | pending_review | evidence-dispatched |
| s-resource | observed | observed | pending_review | evidence-dispatched |
| s-english | observed | observed | pending_review | evidence-dispatched |
| s-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| m-direct | observed | observed | pending_review | evidence-dispatched |
| m-rephrase | observed | observed | pending_review | evidence-dispatched |
| m-omitted | not_observed | not_observed | pending_review | candidate-not-observed |
| m-superseded | observed | observed | pending_review | evidence-dispatched |
| m-english | observed | observed | pending_review | evidence-dispatched |
| m-revoked | not_applicable | not_applicable | pending_review | negative-scope-review |
| o-direct | observed | observed | pending_review | evidence-dispatched |
| o-rephrase | observed | not_observed | pending_review | candidate-without-evidence |
| o-nearby | observed | observed | pending_review | evidence-dispatched |
| o-nonzero | observed | not_observed | pending_review | candidate-without-evidence |
| o-english | observed | not_observed | pending_review | candidate-without-evidence |
| o-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| h-direct | observed | observed | pending_review | evidence-dispatched |
| h-rephrase | observed | observed | pending_review | evidence-dispatched |
| h-late-page | observed | observed | pending_review | evidence-dispatched |
| h-disambiguate | observed | observed | pending_review | evidence-dispatched |
| h-english | observed | observed | pending_review | evidence-dispatched |
| h-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| s-direct | observed | observed | pending_review | evidence-dispatched |
| s-rephrase | observed | observed | pending_review | evidence-dispatched |
| s-large-directory | observed | observed | pending_review | evidence-dispatched |
| s-resource | observed | observed | pending_review | evidence-dispatched |
| s-english | observed | observed | pending_review | evidence-dispatched |
| s-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| m-direct | observed | observed | pending_review | evidence-dispatched |
| m-rephrase | observed | observed | pending_review | evidence-dispatched |
| m-omitted | not_observed | not_observed | pending_review | candidate-not-observed |
| m-superseded | observed | observed | pending_review | evidence-dispatched |
| m-english | observed | observed | pending_review | evidence-dispatched |
| m-revoked | not_applicable | not_applicable | pending_review | negative-scope-review |
| o-direct | observed | observed | pending_review | evidence-dispatched |
| o-rephrase | observed | not_observed | pending_review | candidate-without-evidence |
| o-nearby | observed | observed | pending_review | evidence-dispatched |
| o-nonzero | observed | not_observed | pending_review | candidate-without-evidence |
| o-english | observed | observed | pending_review | evidence-dispatched |
| o-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| h-direct | observed | observed | pending_review | evidence-dispatched |
| h-rephrase | observed | observed | pending_review | evidence-dispatched |
| h-late-page | observed | observed | pending_review | evidence-dispatched |
| h-disambiguate | observed | observed | pending_review | evidence-dispatched |
| h-english | observed | observed | pending_review | evidence-dispatched |
| h-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| s-direct | observed | observed | pending_review | evidence-dispatched |
| s-rephrase | observed | observed | pending_review | evidence-dispatched |
| s-large-directory | observed | observed | pending_review | evidence-dispatched |
| s-resource | observed | observed | pending_review | evidence-dispatched |
| s-english | observed | not_observed | pending_review | candidate-without-evidence |
| s-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| m-direct | observed | observed | pending_review | evidence-dispatched |
| m-rephrase | observed | observed | pending_review | evidence-dispatched |
| m-omitted | not_observed | not_observed | pending_review | candidate-not-observed |
| m-superseded | observed | observed | pending_review | evidence-dispatched |
| m-english | observed | observed | pending_review | evidence-dispatched |
| m-revoked | not_applicable | not_applicable | pending_review | negative-scope-review |
| o-direct | observed | observed | pending_review | evidence-dispatched |
| o-rephrase | observed | not_observed | pending_review | candidate-without-evidence |
| o-nearby | observed | observed | pending_review | evidence-dispatched |
| o-nonzero | observed | not_observed | pending_review | candidate-without-evidence |
| o-english | observed | observed | pending_review | evidence-dispatched |
| o-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
