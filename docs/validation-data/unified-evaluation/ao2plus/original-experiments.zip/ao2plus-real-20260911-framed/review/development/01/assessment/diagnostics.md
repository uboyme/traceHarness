## Retrieval diagnostics

相关来源候选只定位来源容器；目录不等于正文。派发只证明内容进入请求，不证明模型已理解。
读取回执不证明正文已送达；完整有效搜索片段不需要额外 read。
负例按原查询、字段和分页范围审阅，不把查询无命中当成全库不存在。
observed=已出现，not_observed=本条轨迹未出现，unknown=未知，not_applicable=不适用。
pending_review=待人工审阅；provisional 匹配不是正式评分。

| 题目 ID | 相关来源候选 | 足够证据派发 | 回答评估 | 观测缺口 |
|---|---|---|---|---|
| s-direct | observed | observed | passed | evidence-dispatched |
| s-resource | observed | observed | passed | evidence-dispatched |
| s-absent | not_applicable | not_applicable | failed | negative-scope-review |
| s-english | observed | not_observed | failed | candidate-without-evidence |

```json
{
  "format": 1,
  "binding": {
    "run_id": "eff29beb-5a29-456e-9112-d468e010ef30",
    "frozen_digest": "1f2126759a6ae6fea3364fd84f503d569cffc9d50a52a9e2d3daed26baa6071f",
    "evidence_digest": "3b332cf9d55465db6f376f3e64be9127b68a3f9e5cd9038475211c7b74ca0435",
    "report_digest": "1aca5d64968a35e7ff4f857b437fc9dd04519a52e09442337da36b28c61dd349",
    "scorer_id": "retrieval-evidence-v1",
    "scorer_version": 1,
    "rubric_digest": "60da87b9426407b8fe5af8a016a1388838346ec9c58c13b462171a220108d3d0"
  },
  "analyzer": {
    "version": 1,
    "source_digest": "5b51bbe4ce7aadf42baf2c5cf7a1f6ed292c314ed5eedd67e07833fd3ef8d493"
  },
  "rows": [
    {
      "trial_id": "be2f9a592409b7200da3d8bc04290d73a0370c260054500a05d21b699c632ffe",
      "case_id": "s-direct",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer states '设备演练手册规定的签到卡代号是 **REF-CF662C1BCD**。', which matches the expected value 'REF-CF662C1BCD' from the expectation. The dispatched evidence includes a visible section excerpt: '设备演练签到后发放代号为 REF-CF662C1BCD 的签到卡。', which directly supports the claim and contains the exact code. The evidence was successfully requested via request_skill_reference (call_seq 15, succeeded at result_seq 17) and is present in visible_evidence as a skill/section body. Attribution is implicit in the answer's phrasing ('设备演练手册规定的...'), aligning with the reference_id 'manual-cf662c1bcd'. No unsupported claims or scope violations are present; the answer is concise, correct, and grounded solely in the dispatched and visible evidence."
      },
      "provisional_answer_match": true,
      "question": "设备演练手册规定的签到卡代号是什么？",
      "answer": "设备演练手册规定的签到卡代号是 **REF-CF662C1BCD**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "1809c8db-19b1-4452-84a2-b5195650b49d",
              "dispatch_fingerprint": "a51beb36f04cc206804e6ef4ced5af4387ac94540cb419d55a664e026c210172",
              "context_seq": 7,
              "id": "manual-cf662c1bcd",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "manual-cf662c1bcd"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "cbcd62bd-6add-48a7-9730-d9dcd6fec55d",
              "dispatch_fingerprint": "1f53121eca30217fb0d957fa90daf04cdaf65782dca1d2b9c5ae116481a70231",
              "context_seq": 20,
              "id": "manual-cf662c1bcd",
              "version": "1.0.0",
              "tier": "section",
              "provenance": {
                "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": "section-23",
                "skill_id": "manual-cf662c1bcd"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "cbcd62bd-6add-48a7-9730-d9dcd6fec55d",
              "dispatch_fingerprint": "1f53121eca30217fb0d957fa90daf04cdaf65782dca1d2b9c5ae116481a70231",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "manual-cf662c1bcd",
                "provenance": {
                  "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
                  "chunk_id": null,
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": null,
                  "section_id": "section-23",
                  "skill_id": "manual-cf662c1bcd"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "1809c8db-19b1-4452-84a2-b5195650b49d",
            "dispatch_fingerprint": "a51beb36f04cc206804e6ef4ced5af4387ac94540cb419d55a664e026c210172",
            "context_seq": 7,
            "id": "manual-cf662c1bcd",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-cf662c1bcd"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "cbcd62bd-6add-48a7-9730-d9dcd6fec55d",
            "dispatch_fingerprint": "1f53121eca30217fb0d957fa90daf04cdaf65782dca1d2b9c5ae116481a70231",
            "context_seq": 20,
            "id": "manual-cf662c1bcd",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-cf662c1bcd"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_361e60d56ba34873827a4f",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
              "chunk_id": null,
              "requested_tier": "section",
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-cf662c1bcd",
              "version": "1.0.0"
            },
            "requested_tier": "section",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "c2f6ed5bf2a200b3cab1c52b654a618fa6097090967ac8f3139ef9c61206c90b",
      "case_id": "s-resource",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer '值班呼号是 `REF-EC8DE757AB`。' correctly states the值班呼号 as REF-EC8DE757AB, matching the expected value. The dispatched evidence includes a visible skill chunk with body '应急联络卡规定值班呼号为 REF-EC8DE757AB。', which directly supports the answer. Attribution is implicit via the skill reference (id: manual-ec8de757ab, chunk_id: chunk-ec8de757ab), and the read_request confirms successful retrieval of that exact chunk. No unsupported claims or scope violations are present. The evidence is authoritative, excerpted, and sufficient per rubric: a complete authoritative search excerpt suffices; arbitrary read counts are not required."
      },
      "provisional_answer_match": true,
      "question": "档案整理手册的应急联络卡上，值班呼号是什么？",
      "answer": "值班呼号是 `REF-EC8DE757AB`。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "e8c556b5-c10f-4713-8c72-beac0e593b97",
              "dispatch_fingerprint": "3d45406c76576bb6292f948bc3e5f84eb03ef07df2614d59b55d00fbcad1d4de",
              "context_seq": 7,
              "id": "manual-ec8de757ab",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "manual-ec8de757ab"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "c0d76a8b-7989-4c8e-a006-4f031c81eb01",
              "dispatch_fingerprint": "ff781cf2e3ff510affc6fb8852c850f7e0489d96aeb5d0603301eac71babac32",
              "context_seq": 20,
              "id": "manual-ec8de757ab",
              "version": "1.0.0",
              "tier": "chunk",
              "provenance": {
                "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
                "chunk_id": "chunk-ec8de757ab",
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": "resource-ec8de757ab",
                "section_id": null,
                "skill_id": "manual-ec8de757ab"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "c0d76a8b-7989-4c8e-a006-4f031c81eb01",
              "dispatch_fingerprint": "ff781cf2e3ff510affc6fb8852c850f7e0489d96aeb5d0603301eac71babac32",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "manual-ec8de757ab",
                "provenance": {
                  "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
                  "chunk_id": "chunk-ec8de757ab",
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": "resource-ec8de757ab",
                  "section_id": null,
                  "skill_id": "manual-ec8de757ab"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "e8c556b5-c10f-4713-8c72-beac0e593b97",
            "dispatch_fingerprint": "3d45406c76576bb6292f948bc3e5f84eb03ef07df2614d59b55d00fbcad1d4de",
            "context_seq": 7,
            "id": "manual-ec8de757ab",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-ec8de757ab"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "c0d76a8b-7989-4c8e-a006-4f031c81eb01",
            "dispatch_fingerprint": "ff781cf2e3ff510affc6fb8852c850f7e0489d96aeb5d0603301eac71babac32",
            "context_seq": 20,
            "id": "manual-ec8de757ab",
            "version": "1.0.0",
            "tier": "chunk",
            "provenance": {
              "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
              "chunk_id": "chunk-ec8de757ab",
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": "resource-ec8de757ab",
              "section_id": null,
              "skill_id": "manual-ec8de757ab"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_b143993783da48e88a9945",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
              "chunk_id": "chunk-ec8de757ab",
              "requested_tier": "chunk",
              "resource_id": "resource-ec8de757ab",
              "section_id": null,
              "skill_id": "manual-ec8de757ab",
              "version": "1.0.0"
            },
            "requested_tier": "chunk",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "e71301b6b55965b8245df65dc03ab4a7c871d601571e0f68afc544e8ee6bd00a",
      "case_id": "s-absent",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "failed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer claims the manual 'has no provision' for vehicle fuel discount codes and concludes 'No', but this overstates the evidence. Searches were limited to navigation metadata (id/title/summary/tags) of 32 records — not the full text of the manual's sections or bodies. The visible evidence shows only a directory listing and one section excerpt ('本手册说明档案整理工作。'), with no inspection of actual operational rules, appendices, or policy tables that might contain discount code provisions. The rubric forbids treating a local no-hit in navigation fields as global absence; the answer violates this by asserting definitive absence without examining hidden skill bodies (hidden_skill_bodies_searched=false in both searches) and without citing any authoritative statement from the manual’s content that excludes such provisions. Thus, the negative conclusion is unsupported."
      },
      "provisional_answer_match": null,
      "question": "档案整理手册有没有规定车辆加油的折扣码？",
      "answer": "根据搜索结果，我在档案整理手册中搜索了\"车辆加油\"和\"加油\"关键词，但都没有找到匹配内容（no-hit结果）。\n\n档案整理手册的摘要只显示\"本手册说明档案整理工作。\"，这表明该手册专注于档案整理相关的工作流程和规范，与车辆加油、折扣码等后勤或财务事项无关。\n\n因此，档案整理手册**没有规定**车辆加油的折扣码。车辆加油折扣码通常属于公司财务管理、行政后勤或采购政策的范畴，而不是档案整理工作的内容。\n\n答案：没有。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "not_applicable",
          "granularity": "source-container",
          "observations": []
        },
        "evidence": {
          "status": "not_applicable",
          "observations": []
        },
        "gap": "negative-scope-review",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "94881743-1228-4233-8b9b-ea75eebca944",
            "dispatch_fingerprint": "62da10c7c1cea6845cdcb8ab91278d09ecc7ee94bd8d75334cac24a56bfd35f7",
            "context_seq": 7,
            "id": "manual-593410eb3c",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "7efa2afefd848720123a6a4d3981a884acc4599e6cc1dc8c23c20229c9ed16f0",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-593410eb3c"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "6bd36b7c-2af1-44eb-9680-54e4c7357e4f",
            "dispatch_fingerprint": "d63f8c58946bf06f346d9ab8c9495b29b45be9be77b6a19e2258ac09f2573f55",
            "context_seq": 20,
            "id": "manual-593410eb3c",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "7efa2afefd848720123a6a4d3981a884acc4599e6cc1dc8c23c20229c9ed16f0",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-593410eb3c"
            }
          },
          {
            "request_snapshot_seq": 36,
            "attempt_id": "58e36604-7bd7-45a2-a621-e712e94fb177",
            "dispatch_fingerprint": "781394bc4422ef4575a2c35eb8d115f04a73c9d585b742b022cb9202c599665e",
            "context_seq": 33,
            "id": "711d5ee2d50d9644ba76cc7581ae0b1e688f53e69e75393b0835abe9d22c30c3",
            "version": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "1684cec4480dec7873e1d0dc0b9e089c2e61cc5145e2110eb3f161a87e7943df",
                "event_id": "ed736d95-9883-431e-ab0f-3f090e4116e6",
                "seq": 30,
                "stream_id": "session:b5f90793-aab6-48e2-a26d-3c011789265c",
                "type": "tool/result"
              },
              "source_digest": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a"
            }
          },
          {
            "request_snapshot_seq": 36,
            "attempt_id": "58e36604-7bd7-45a2-a621-e712e94fb177",
            "dispatch_fingerprint": "781394bc4422ef4575a2c35eb8d115f04a73c9d585b742b022cb9202c599665e",
            "context_seq": 33,
            "id": "manual-593410eb3c",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "7efa2afefd848720123a6a4d3981a884acc4599e6cc1dc8c23c20229c9ed16f0",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-593410eb3c"
            }
          },
          {
            "request_snapshot_seq": 49,
            "attempt_id": "3ac7948f-2d3a-4f73-ba02-635e92871ce7",
            "dispatch_fingerprint": "15ecfa02c4c6bdce04348a57cd98ef793fce95d05feaa90870e3ef9065760fab",
            "context_seq": 46,
            "id": "bc71786c8a256ab6f1de90abec833d1f574c63a251691271fef016125d5b1269",
            "version": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "eeb87ef9273fafac1f88634cc162402884ac6eea9da891dbbc4585dce1316240",
                "event_id": "52431896-0e15-4e25-abec-5ebd00141495",
                "seq": 43,
                "stream_id": "session:b5f90793-aab6-48e2-a26d-3c011789265c",
                "type": "tool/result"
              },
              "source_digest": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a"
            }
          },
          {
            "request_snapshot_seq": 49,
            "attempt_id": "3ac7948f-2d3a-4f73-ba02-635e92871ce7",
            "dispatch_fingerprint": "15ecfa02c4c6bdce04348a57cd98ef793fce95d05feaa90870e3ef9065760fab",
            "context_seq": 46,
            "id": "manual-593410eb3c",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "7efa2afefd848720123a6a4d3981a884acc4599e6cc1dc8c23c20229c9ed16f0",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-593410eb3c"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_23b9df35e1cf4ec9a21090",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "7efa2afefd848720123a6a4d3981a884acc4599e6cc1dc8c23c20229c9ed16f0",
              "chunk_id": null,
              "requested_tier": "section",
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-593410eb3c",
              "version": "1.0.0"
            },
            "requested_tier": "section",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [
          {
            "request_snapshot_seq": 36,
            "attempt_id": "58e36604-7bd7-45a2-a621-e712e94fb177",
            "dispatch_fingerprint": "781394bc4422ef4575a2c35eb8d115f04a73c9d585b742b022cb9202c599665e",
            "context_seq": 33,
            "id": "711d5ee2d50d9644ba76cc7581ae0b1e688f53e69e75393b0835abe9d22c30c3",
            "version": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "1684cec4480dec7873e1d0dc0b9e089c2e61cc5145e2110eb3f161a87e7943df",
                "event_id": "ed736d95-9883-431e-ab0f-3f090e4116e6",
                "seq": 30,
                "stream_id": "session:b5f90793-aab6-48e2-a26d-3c011789265c",
                "type": "tool/result"
              },
              "source_digest": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a"
            },
            "domain": "skill-navigation",
            "query": "车辆加油",
            "fields": [
              "id",
              "title",
              "summary",
              "tags"
            ],
            "status": "no-hit",
            "scanned": 32,
            "total": 32,
            "next_cursor": null,
            "hit_count": 0,
            "proves_global_absence": false
          },
          {
            "request_snapshot_seq": 49,
            "attempt_id": "3ac7948f-2d3a-4f73-ba02-635e92871ce7",
            "dispatch_fingerprint": "15ecfa02c4c6bdce04348a57cd98ef793fce95d05feaa90870e3ef9065760fab",
            "context_seq": 46,
            "id": "bc71786c8a256ab6f1de90abec833d1f574c63a251691271fef016125d5b1269",
            "version": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "eeb87ef9273fafac1f88634cc162402884ac6eea9da891dbbc4585dce1316240",
                "event_id": "52431896-0e15-4e25-abec-5ebd00141495",
                "seq": 43,
                "stream_id": "session:b5f90793-aab6-48e2-a26d-3c011789265c",
                "type": "tool/result"
              },
              "source_digest": "19704c711281c42fac67383af7b89a4a2fd3ee60dfb6298af8a172678bb1cf0a"
            },
            "domain": "skill-navigation",
            "query": "加油",
            "fields": [
              "id",
              "title",
              "summary",
              "tags"
            ],
            "status": "no-hit",
            "scanned": 32,
            "total": 32,
            "next_cursor": null,
            "hit_count": 0,
            "proves_global_absence": false
          }
        ],
        "negative_scope_review_required": true,
        "successful_answer_dispatches": 4,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "8e6cd6760c2e65abe41cb0fe47fb5c4285c23c429b5a4cc77a5a056918451ed6",
      "case_id": "s-english",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "failed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "program gate: required source evidence never reached a model request"
      },
      "provisional_answer_match": false,
      "question": "Which code does the equipment drill manual specify for the check-in card?",
      "answer": "The current references do not contain the equipment drill manual or any information about a check-in card code. Since the search_skill for \"equipment drill manual\" only returned a summary without the required details, and no other relevant references are available, I cannot determine the specified code for the check-in card from the provided materials.\n\nTo proceed, I would need either:\n- Access to the full equipment drill manual (e.g., via request_skill_reference with the correct section/chunk ID), or\n- Additional context or documentation that specifies the check-in card code.\n\nWithout this information, the question cannot be answered definitively.",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "e1799a1c-2ff0-41da-b04e-7fd4a045cde7",
              "dispatch_fingerprint": "e122e7cf5a665f8fd1a6f086741f5b9c973071db518994a3c9f8d1a534c6323d",
              "context_seq": 20,
              "id": "b0cc0e2584f75539ba580dcc7a7c84731c179eeed7b0790de09ab326b945da56",
              "version": "8911d605723ed9d90c73cce4a505da1006a2a17637a300e58b3c1ebb41dfc4a8",
              "tier": "search",
              "provenance": {
                "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
                "request_ref": {
                  "digest": "ef71f8d7fbdf172b1b9a994c960000858baa732affdb49f8c8c1aad442d8f7de",
                  "event_id": "1c086b2f-9e4d-43ee-bd6e-b319dfaf4e89",
                  "seq": 17,
                  "stream_id": "session:16443c55-902d-44f3-a89b-88508880e47f",
                  "type": "tool/result"
                },
                "source_digest": "8911d605723ed9d90c73cce4a505da1006a2a17637a300e58b3c1ebb41dfc4a8"
              }
            }
          ]
        },
        "evidence": {
          "status": "not_observed",
          "observations": []
        },
        "gap": "candidate-without-evidence",
        "source_views": [
          {
            "request_snapshot_seq": 23,
            "attempt_id": "e1799a1c-2ff0-41da-b04e-7fd4a045cde7",
            "dispatch_fingerprint": "e122e7cf5a665f8fd1a6f086741f5b9c973071db518994a3c9f8d1a534c6323d",
            "context_seq": 20,
            "id": "b0cc0e2584f75539ba580dcc7a7c84731c179eeed7b0790de09ab326b945da56",
            "version": "8911d605723ed9d90c73cce4a505da1006a2a17637a300e58b3c1ebb41dfc4a8",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "ef71f8d7fbdf172b1b9a994c960000858baa732affdb49f8c8c1aad442d8f7de",
                "event_id": "1c086b2f-9e4d-43ee-bd6e-b319dfaf4e89",
                "seq": 17,
                "stream_id": "session:16443c55-902d-44f3-a89b-88508880e47f",
                "type": "tool/result"
              },
              "source_digest": "8911d605723ed9d90c73cce4a505da1006a2a17637a300e58b3c1ebb41dfc4a8"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 28,
            "tool_call_id": "call_bb6d047bb963456e8caecd",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "2181fa5e05ba14aefec6fd90c937814090cca471c95e33b69bed59cbc64bbfba",
              "chunk_id": null,
              "requested_tier": "directory",
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-ea333bb356",
              "version": "1.0.0"
            },
            "requested_tier": "directory",
            "result_seq": 30,
            "status": "failed",
            "error_type": "ValueError"
          }
        ],
        "search_coverage": [
          {
            "request_snapshot_seq": 23,
            "attempt_id": "e1799a1c-2ff0-41da-b04e-7fd4a045cde7",
            "dispatch_fingerprint": "e122e7cf5a665f8fd1a6f086741f5b9c973071db518994a3c9f8d1a534c6323d",
            "context_seq": 20,
            "id": "b0cc0e2584f75539ba580dcc7a7c84731c179eeed7b0790de09ab326b945da56",
            "version": "8911d605723ed9d90c73cce4a505da1006a2a17637a300e58b3c1ebb41dfc4a8",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "ef71f8d7fbdf172b1b9a994c960000858baa732affdb49f8c8c1aad442d8f7de",
                "event_id": "1c086b2f-9e4d-43ee-bd6e-b319dfaf4e89",
                "seq": 17,
                "stream_id": "session:16443c55-902d-44f3-a89b-88508880e47f",
                "type": "tool/result"
              },
              "source_digest": "8911d605723ed9d90c73cce4a505da1006a2a17637a300e58b3c1ebb41dfc4a8"
            },
            "domain": "skill-navigation",
            "query": "equipment drill manual",
            "fields": [
              "id",
              "title",
              "summary",
              "tags"
            ],
            "status": "matches",
            "scanned": 32,
            "total": 32,
            "next_cursor": null,
            "hit_count": 1,
            "proves_global_absence": false
          }
        ],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 3,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    }
  ]
}
```
