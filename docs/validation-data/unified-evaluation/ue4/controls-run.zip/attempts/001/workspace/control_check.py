from pathlib import Path
p=Path('control-executions.txt')
p.write_text(str(int(p.read_text())+1) if p.exists() else '1')
for i in range(100): print('ordinary equipment record', i)
print('设备巡检本次输出的交接核验码=OUT-D7N3')
