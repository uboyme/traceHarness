## Retrieval diagnostics

相关来源候选只定位来源容器；目录不等于正文。派发只证明内容进入请求，不证明模型已理解。
读取回执不证明正文已送达；完整有效搜索片段不需要额外 read。
负例按原查询、字段和分页范围审阅，不把查询无命中当成全库不存在。
observed=已出现，not_observed=本条轨迹未出现，unknown=未知，not_applicable=不适用。
pending_review=待人工审阅；provisional 匹配不是正式评分。

| 题目 ID | 相关来源候选 | 足够证据派发 | 回答评估 | 观测缺口 |
|---|---|---|---|---|
| s-direct | observed | observed | passed | evidence-dispatched |
| s-resource | observed | observed | passed | evidence-dispatched |
| s-absent | not_applicable | not_applicable | failed | negative-scope-review |
| s-english | observed | observed | passed | evidence-dispatched |

```json
{
  "format": 1,
  "binding": {
    "run_id": "205e9015-802b-46f9-828d-fce8a58c52d2",
    "frozen_digest": "eec974bddaf2d08db2570f02322057d9f55e571f11610956617cb584cb66b674",
    "evidence_digest": "5c762f9f32f67ba2a18d2d3b5d55f29eaf4b7adffe70b5898247af0e12844241",
    "report_digest": "0f1fa264218ef8a1cd490bd82606390b636af47ed07272f6b8afe9b1e67b403c",
    "scorer_id": "retrieval-evidence-v1",
    "scorer_version": 1,
    "rubric_digest": "60da87b9426407b8fe5af8a016a1388838346ec9c58c13b462171a220108d3d0"
  },
  "analyzer": {
    "version": 1,
    "source_digest": "5b51bbe4ce7aadf42baf2c5cf7a1f6ed292c314ed5eedd67e07833fd3ef8d493"
  },
  "rows": [
    {
      "trial_id": "f4174f12466c9ec47545f709664da3d7cc75fb4bfbf03f12a7f96618984b0a76",
      "case_id": "s-direct",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer correctly states the签到卡代号 as 'REF-CF662C1BCD', which exactly matches the value in the expectation and is directly supported by the dispatched evidence: the visible section body '设备演练签到后发放代号为 REF-CF662C1BCD 的签到卡。' (from skill manual-cf662c1bcd, section-23). The answer includes proper attribution ('根据提供的设备演练手册内容'), no unsupported claims, and no scope violation. The evidence was dispatched before answering (per dispatched_evidence array), and the view digest confirms a 'visible-source-excerpt' of the section was admitted. All rubric requirements for a positive answer are satisfied."
      },
      "provisional_answer_match": true,
      "question": "设备演练手册规定的签到卡代号是什么？",
      "answer": "根据提供的设备演练手册内容，签到卡的代号是 **REF-CF662C1BCD**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "9c33b9e6-622e-4875-a2a2-6a65a3511524",
              "dispatch_fingerprint": "88b8b83a80bbd32d271230e3a8aac04d1d01b860188103977097117fe5390a8f",
              "context_seq": 7,
              "id": "manual-cf662c1bcd",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "manual-cf662c1bcd"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "6a1017f8-a805-4cb1-9850-bf9a3660b507",
              "dispatch_fingerprint": "e5386383cea4cfae2d8c7536d1c4bd8335d713df60f46b0420cf9de238a422af",
              "context_seq": 20,
              "id": "manual-cf662c1bcd",
              "version": "1.0.0",
              "tier": "section",
              "provenance": {
                "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": "section-23",
                "skill_id": "manual-cf662c1bcd"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "6a1017f8-a805-4cb1-9850-bf9a3660b507",
              "dispatch_fingerprint": "e5386383cea4cfae2d8c7536d1c4bd8335d713df60f46b0420cf9de238a422af",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "manual-cf662c1bcd",
                "provenance": {
                  "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
                  "chunk_id": null,
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": null,
                  "section_id": "section-23",
                  "skill_id": "manual-cf662c1bcd"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "9c33b9e6-622e-4875-a2a2-6a65a3511524",
            "dispatch_fingerprint": "88b8b83a80bbd32d271230e3a8aac04d1d01b860188103977097117fe5390a8f",
            "context_seq": 7,
            "id": "manual-cf662c1bcd",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-cf662c1bcd"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "6a1017f8-a805-4cb1-9850-bf9a3660b507",
            "dispatch_fingerprint": "e5386383cea4cfae2d8c7536d1c4bd8335d713df60f46b0420cf9de238a422af",
            "context_seq": 20,
            "id": "manual-cf662c1bcd",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-cf662c1bcd"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_4ce2111ad0b3468f95655f",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "875a8fd32c461fcdd179ced8364702865e42a35d93eed4a2099e67b771eb41bf",
              "chunk_id": null,
              "requested_tier": "section",
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-cf662c1bcd",
              "version": "1.0.0"
            },
            "requested_tier": "section",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "4710014a985bc089331b488cdaa642c191cab5290630c7b0e24f62c912f132be",
      "case_id": "s-resource",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer correctly states the值班呼号 as 'REF-EC8DE757AB', which exactly matches the expected value. The evidence is dispatched and visible: the skill chunk body contains the exact string '应急联络卡规定值班呼号为 REF-EC8DE757AB。', and the read request for that chunk succeeded. Attribution is proper ('根据提供的档案整理手册技能文档'). No unsupported claims are made, and the answer scope is limited to the question. The evidence_scope confirms the chunk was viewed as a visible-source-excerpt, satisfying the rubric's requirement for a complete authoritative excerpt."
      },
      "provisional_answer_match": true,
      "question": "档案整理手册的应急联络卡上，值班呼号是什么？",
      "answer": "根据提供的档案整理手册技能文档，应急联络卡上规定的值班呼号是 **REF-EC8DE757AB**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "1f6cbf66-a258-4980-8442-85560ee7c327",
              "dispatch_fingerprint": "f11381abb18c9422e10cb5ef6aaacbc227f62d370744c9a9b85c10fe41ce884b",
              "context_seq": 7,
              "id": "manual-ec8de757ab",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "manual-ec8de757ab"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "f9cc2d70-222c-4d55-957e-1ae81eecbed0",
              "dispatch_fingerprint": "445bfa3b3f1ded539ad84807e9ea2fccf2bc87844537073abc4c03641ed27901",
              "context_seq": 20,
              "id": "manual-ec8de757ab",
              "version": "1.0.0",
              "tier": "chunk",
              "provenance": {
                "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
                "chunk_id": "chunk-ec8de757ab",
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": "resource-ec8de757ab",
                "section_id": null,
                "skill_id": "manual-ec8de757ab"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "f9cc2d70-222c-4d55-957e-1ae81eecbed0",
              "dispatch_fingerprint": "445bfa3b3f1ded539ad84807e9ea2fccf2bc87844537073abc4c03641ed27901",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "manual-ec8de757ab",
                "provenance": {
                  "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
                  "chunk_id": "chunk-ec8de757ab",
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": "resource-ec8de757ab",
                  "section_id": null,
                  "skill_id": "manual-ec8de757ab"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "1f6cbf66-a258-4980-8442-85560ee7c327",
            "dispatch_fingerprint": "f11381abb18c9422e10cb5ef6aaacbc227f62d370744c9a9b85c10fe41ce884b",
            "context_seq": 7,
            "id": "manual-ec8de757ab",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-ec8de757ab"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "f9cc2d70-222c-4d55-957e-1ae81eecbed0",
            "dispatch_fingerprint": "445bfa3b3f1ded539ad84807e9ea2fccf2bc87844537073abc4c03641ed27901",
            "context_seq": 20,
            "id": "manual-ec8de757ab",
            "version": "1.0.0",
            "tier": "chunk",
            "provenance": {
              "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
              "chunk_id": "chunk-ec8de757ab",
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": "resource-ec8de757ab",
              "section_id": null,
              "skill_id": "manual-ec8de757ab"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_95c72abf335e4088b8b72a",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "3e79f1df4b28f3a35b6d0c2ed1cbaaeed7db68d567d9e266ab57518c4e3223e4",
              "chunk_id": "chunk-ec8de757ab",
              "requested_tier": "chunk",
              "resource_id": "resource-ec8de757ab",
              "section_id": null,
              "skill_id": "manual-ec8de757ab",
              "version": "1.0.0"
            },
            "requested_tier": "chunk",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "898dd5fd32eefd5d0adc8d0a754ff4037e15864048952c7b876b89138b792e92",
      "case_id": "s-absent",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "failed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer claims '档案整理手册没有规定车辆加油的折扣码' as a definitive, global negative conclusion. However, the evidence only supports a *local absence* in navigation metadata (titles, summaries, tags) — not in the full manual content. The search_coverage explicitly states 'proves_global_absence': false, and 'hidden_skill_bodies_searched': false, meaning the actual section bodies (which may contain discount rules or vehicle-related policies) were never searched or read. The visible_evidence shows all sections have minimal content_bytes (24 or 36), but those bytes are unexamined; the answer incorrectly infers absence of 'discount code' from absence of '车辆加油' in metadata alone. This overstates the search scope and violates the rubric's requirement that negative answers must not overstate a local no-hit as global absence."
      },
      "provisional_answer_match": null,
      "question": "档案整理手册有没有规定车辆加油的折扣码？",
      "answer": "搜索结果显示没有找到与\"车辆加油\"相关的章节或内容。搜索返回了\"no-hit\"状态，表明在档案整理手册的目录结构中没有包含\"车辆加油\"关键词的章节。\n\n从手册的目录信息来看，所有章节（section-00到section-30）的摘要都是\"说明普通器材登记。\"，只有section-23的摘要是\"档案整理操作手册\"，但也没有提到车辆加油或折扣码相关内容。\n\n因此，根据现有的档案整理手册目录信息，**档案整理手册没有规定车辆加油的折扣码**。\n\n这个结论基于手册的目录结构和搜索结果，手册主要关注档案整理操作和普通器材登记，不涉及车辆加油管理或折扣码规定。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "not_applicable",
          "granularity": "source-container",
          "observations": []
        },
        "evidence": {
          "status": "not_applicable",
          "observations": []
        },
        "gap": "negative-scope-review",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "83056d7d-32d4-462d-ac42-eac4fefa7b4f",
            "dispatch_fingerprint": "75030db35666f7f7e5b4c0dd3f52561eff3621d49d404d2d92157c21f808e458",
            "context_seq": 7,
            "id": "manual-593410eb3c",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "7efa2afefd848720123a6a4d3981a884acc4599e6cc1dc8c23c20229c9ed16f0",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-593410eb3c"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "aaf63f30-bd7e-46f0-96e7-30aba449603d",
            "dispatch_fingerprint": "289591d49065fdd11a1d0ead8ef0052de2ee5a7eea0e07cbe33102dc400c4a82",
            "context_seq": 20,
            "id": "18326686478bf2084384c839a83f36e4c65abf093e977616edbd191bd7984822",
            "version": "ec228fad75120a5f9b2b64b33c17384bc67f2a2f3a8e5a835be78b08bb43d56f",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "f528fa22b53c547b8e3442606898f58e9c5c398413576f1fad2e97c617184c95",
                "event_id": "70e0ba81-2b52-4587-ac9c-b13fae66c69d",
                "seq": 17,
                "stream_id": "session:1b739e1f-1c2f-4e44-9936-5f048fbf5432",
                "type": "tool/result"
              },
              "source_digest": "ec228fad75120a5f9b2b64b33c17384bc67f2a2f3a8e5a835be78b08bb43d56f"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "aaf63f30-bd7e-46f0-96e7-30aba449603d",
            "dispatch_fingerprint": "289591d49065fdd11a1d0ead8ef0052de2ee5a7eea0e07cbe33102dc400c4a82",
            "context_seq": 20,
            "id": "manual-593410eb3c",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "7efa2afefd848720123a6a4d3981a884acc4599e6cc1dc8c23c20229c9ed16f0",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "manual-593410eb3c"
            }
          }
        ],
        "read_requests": [],
        "search_coverage": [
          {
            "request_snapshot_seq": 23,
            "attempt_id": "aaf63f30-bd7e-46f0-96e7-30aba449603d",
            "dispatch_fingerprint": "289591d49065fdd11a1d0ead8ef0052de2ee5a7eea0e07cbe33102dc400c4a82",
            "context_seq": 20,
            "id": "18326686478bf2084384c839a83f36e4c65abf093e977616edbd191bd7984822",
            "version": "ec228fad75120a5f9b2b64b33c17384bc67f2a2f3a8e5a835be78b08bb43d56f",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "f528fa22b53c547b8e3442606898f58e9c5c398413576f1fad2e97c617184c95",
                "event_id": "70e0ba81-2b52-4587-ac9c-b13fae66c69d",
                "seq": 17,
                "stream_id": "session:1b739e1f-1c2f-4e44-9936-5f048fbf5432",
                "type": "tool/result"
              },
              "source_digest": "ec228fad75120a5f9b2b64b33c17384bc67f2a2f3a8e5a835be78b08bb43d56f"
            },
            "domain": "skill-navigation",
            "query": "车辆加油",
            "fields": [
              "id",
              "title",
              "summary",
              "tags"
            ],
            "status": "no-hit",
            "scanned": 32,
            "total": 32,
            "next_cursor": null,
            "hit_count": 0,
            "proves_global_absence": false
          }
        ],
        "negative_scope_review_required": true,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "c7996fc7695db675f8229a78a749ca70f4da3c3f3e813f9f10af6c2420e43c8f",
      "case_id": "s-english",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer correctly states the check-in card code as 'REF-EA333BB356', matching the expectation's value. The evidence is properly attributed to the skill reference 'manual-ea333bb356', section-23, and the exact source text 'The equipment drill check-in card code is REF-EA333BB356.' is present in visible_evidence (third item). The read_request for that section succeeded, and the dispatched evidence confirms the text was retrieved before answering. No unsupported claims or scope violations are present; the answer is precise, attributed, and grounded in the admitted evidence."
      },
      "provisional_answer_match": true,
      "question": "Which code does the equipment drill manual specify for the check-in card?",
      "answer": "The equipment drill manual specifies the check-in card code as **REF-EA333BB356**.",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "1ca75466-a4a8-442b-bdf4-2fac5abee54e",
              "dispatch_fingerprint": "f7c1c5b33179e69a9618156e620fa6a810d1e4b85b7e647f0e729db32583dc0d",
              "context_seq": 20,
              "id": "2ed85a3ce033676638fbea84e14491ef2480ba55585694e264287eca36f1edab",
              "version": "e36ab8b597b3d881741ce089fff9c160bcec163580d5a892b1d5e9fe6e11e1c4",
              "tier": "search",
              "provenance": {
                "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
                "request_ref": {
                  "digest": "ffde3dc9ef9bc1d437a1dd027affc0850cf9ce5cbba6da32829ad7bf593d19f8",
                  "event_id": "a39dc2b9-ec82-4efb-9586-d55281938ff7",
                  "seq": 17,
                  "stream_id": "session:af732194-7291-49d9-975a-a6b07ec41a07",
                  "type": "tool/result"
                },
                "source_digest": "e36ab8b597b3d881741ce089fff9c160bcec163580d5a892b1d5e9fe6e11e1c4"
              }
            },
            {
              "request_snapshot_seq": 36,
              "attempt_id": "17145853-9a2a-4463-87e3-6634cc06a6b6",
              "dispatch_fingerprint": "7d7b2c668ff736d75ff3647531d5de64357a47914e6eb40d9fd27b8ad423099a",
              "context_seq": 33,
              "id": "manual-ea333bb356",
              "version": "1.0.0",
              "tier": "section",
              "provenance": {
                "catalog_digest": "2181fa5e05ba14aefec6fd90c937814090cca471c95e33b69bed59cbc64bbfba",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": "section-23",
                "skill_id": "manual-ea333bb356"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 36,
              "attempt_id": "17145853-9a2a-4463-87e3-6634cc06a6b6",
              "dispatch_fingerprint": "7d7b2c668ff736d75ff3647531d5de64357a47914e6eb40d9fd27b8ad423099a",
              "context_seq": 33,
              "tool_result_seq": null,
              "reference": {
                "id": "manual-ea333bb356",
                "provenance": {
                  "catalog_digest": "2181fa5e05ba14aefec6fd90c937814090cca471c95e33b69bed59cbc64bbfba",
                  "chunk_id": null,
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": null,
                  "section_id": "section-23",
                  "skill_id": "manual-ea333bb356"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 23,
            "attempt_id": "1ca75466-a4a8-442b-bdf4-2fac5abee54e",
            "dispatch_fingerprint": "f7c1c5b33179e69a9618156e620fa6a810d1e4b85b7e647f0e729db32583dc0d",
            "context_seq": 20,
            "id": "2ed85a3ce033676638fbea84e14491ef2480ba55585694e264287eca36f1edab",
            "version": "e36ab8b597b3d881741ce089fff9c160bcec163580d5a892b1d5e9fe6e11e1c4",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "ffde3dc9ef9bc1d437a1dd027affc0850cf9ce5cbba6da32829ad7bf593d19f8",
                "event_id": "a39dc2b9-ec82-4efb-9586-d55281938ff7",
                "seq": 17,
                "stream_id": "session:af732194-7291-49d9-975a-a6b07ec41a07",
                "type": "tool/result"
              },
              "source_digest": "e36ab8b597b3d881741ce089fff9c160bcec163580d5a892b1d5e9fe6e11e1c4"
            }
          },
          {
            "request_snapshot_seq": 36,
            "attempt_id": "17145853-9a2a-4463-87e3-6634cc06a6b6",
            "dispatch_fingerprint": "7d7b2c668ff736d75ff3647531d5de64357a47914e6eb40d9fd27b8ad423099a",
            "context_seq": 33,
            "id": "manual-ea333bb356",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "2181fa5e05ba14aefec6fd90c937814090cca471c95e33b69bed59cbc64bbfba",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-ea333bb356"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 28,
            "tool_call_id": "call_94d24295dadd44eeb87b11",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "2181fa5e05ba14aefec6fd90c937814090cca471c95e33b69bed59cbc64bbfba",
              "chunk_id": null,
              "requested_tier": "section",
              "resource_id": null,
              "section_id": "section-23",
              "skill_id": "manual-ea333bb356",
              "version": "1.0.0"
            },
            "requested_tier": "section",
            "result_seq": 30,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [
          {
            "request_snapshot_seq": 23,
            "attempt_id": "1ca75466-a4a8-442b-bdf4-2fac5abee54e",
            "dispatch_fingerprint": "f7c1c5b33179e69a9618156e620fa6a810d1e4b85b7e647f0e729db32583dc0d",
            "context_seq": 20,
            "id": "2ed85a3ce033676638fbea84e14491ef2480ba55585694e264287eca36f1edab",
            "version": "e36ab8b597b3d881741ce089fff9c160bcec163580d5a892b1d5e9fe6e11e1c4",
            "tier": "search",
            "provenance": {
              "policy_digest": "5fa4f09de62eca8bbc6b4532c9bca8ec17c51317333162a24b35198330b01deb",
              "request_ref": {
                "digest": "ffde3dc9ef9bc1d437a1dd027affc0850cf9ce5cbba6da32829ad7bf593d19f8",
                "event_id": "a39dc2b9-ec82-4efb-9586-d55281938ff7",
                "seq": 17,
                "stream_id": "session:af732194-7291-49d9-975a-a6b07ec41a07",
                "type": "tool/result"
              },
              "source_digest": "e36ab8b597b3d881741ce089fff9c160bcec163580d5a892b1d5e9fe6e11e1c4"
            },
            "domain": "skill-navigation",
            "query": "check-in card",
            "fields": [
              "id",
              "title",
              "summary",
              "tags"
            ],
            "status": "matches",
            "scanned": 32,
            "total": 32,
            "next_cursor": null,
            "hit_count": 1,
            "proves_global_absence": false
          }
        ],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 3,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    }
  ]
}
```
