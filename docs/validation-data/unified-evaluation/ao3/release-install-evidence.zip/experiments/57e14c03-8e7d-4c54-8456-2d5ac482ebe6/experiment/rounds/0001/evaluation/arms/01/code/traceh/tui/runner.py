"""Lazy optional-dependency boundary and lifecycle owner for Textual Chat."""

from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import TYPE_CHECKING

from traceh.chat.activity import Clock, default_clock
from traceh.chat.session import open_chat_session
from traceh.cli.errors import CliConfigurationError
from traceh.concurrency import combine_failures
from traceh.runtime.agent_runtime import AgentRuntime
from traceh.session.service import SessionNotFoundError

if TYPE_CHECKING:
    from argparse import Namespace

    from traceh.cli.tui_entry import RestartChat
    from traceh.product.host import ProductChatHost

TUI_INSTALL_HINT = (
    "Textual TUI is not installed; install the optional extra with "
    "'python -m pip install traceharness-py[tui]'"
)


def require_textual() -> None:
    """Reject a missing optional adapter without silently falling back to Line."""

    if importlib.util.find_spec("textual") is None:
        raise CliConfigurationError(TUI_INSTALL_HINT)


async def run_tui(
    runtime: AgentRuntime,
    *,
    workspace: Path | None,
    session_id: str | None,
    timeline: bool,
    heartbeat_seconds: float,
    product: ProductChatHost | None = None,
    clock: Clock | None = None,
    settings_args: Namespace | None = None,
    background_provider=None,
    background_api_key=None,
) -> int | RestartChat:
    """Open the shared Session, run Textual, then converge shared owners."""

    require_textual()
    primary: BaseException | None = None
    result: int | RestartChat | None = None
    background = None
    try:
        try:
            opened = await open_chat_session(
                runtime,
                workspace=workspace,
                session_id=session_id,
            )
        except NotADirectoryError as error:
            raise CliConfigurationError(
                f"workspace is not a directory: {error}"
            ) from error
        except SessionNotFoundError as error:
            raise CliConfigurationError(f"session not found: {session_id}") from error
        from traceh.tui.app import TracehTuiApp

        if settings_args is not None and getattr(settings_args, "background_config", None):
            from traceh.chat.background import assemble_background, load_background_settings

            settings = load_background_settings(settings_args.background_config)
            if settings.workspace != opened.session.workspace.resolve():
                raise CliConfigurationError("后台优化作用域与当前工作区不一致。")
            if background_provider is None:
                raise CliConfigurationError("后台优化需要显式内置模型连接。")
            background = assemble_background(
                runtime, settings, provider=background_provider, model=runtime.config.model,
                base_url=settings_args.base_url,
                api_key=background_api_key,
            )
            await background.open()

        if settings_args is not None:
            from traceh.chat.workspace_project import restore_workspace_project
            from traceh.tui.session_picker import ProjectChoiceApp

            async def choose(options):
                return await ProjectChoiceApp(options).run_async()

            try:
                await restore_workspace_project(runtime, opened.session.session_id,
                                                settings_args, choose=choose)
            except ValueError:
                raise CliConfigurationError(
                    "项目关联未就绪；请在配置中检查默认项目与署名。已写入的关联保留。"
                ) from None

        app = TracehTuiApp(
            runtime,
            opened,
            timeline=timeline,
            heartbeat_seconds=heartbeat_seconds,
            product=product,
            clock=clock or default_clock(),
            settings_args=settings_args,
            background=background,
        )
        app_result = await app.run_async()
        result = 0 if app_result is None else app_result
    except BaseException as error:
        primary = error
    finally:
        cleanup: BaseException | None = None
        if background is not None:
            try:
                await background.aclose()
            except BaseException as error:
                cleanup = error
        if product is not None:
            try:
                await product.aclose()
            except BaseException as error:
                cleanup = combine_failures(cleanup, error, "TUI product shutdown failed")
        try:
            await runtime.dispose()
        except BaseException as error:
            cleanup = combine_failures(cleanup, error, "TUI runtime shutdown failed")
        combined = combine_failures(primary, cleanup, "TUI shutdown failed")
        if combined is not None:
            if cleanup is not None:
                # A failed close must never be mistaken for a repairable launch
                # configuration error by the interactive restart owner.
                raise BaseExceptionGroup("TUI owners did not close cleanly", [combined])
            raise combined
    assert result is not None
    return result


__all__ = ["TUI_INSTALL_HINT", "require_textual", "run_tui"]
