# Evaluation: retrieval-episodes-development-v1

Run: caf4be26-2433-4a75-bc3c-fac2fb838338
Task type: retrieval_episode
Measurement complete: True
Assessment complete: False

| Trial | Execution | Assessment | Convergence |
|---|---|---|---|
| be2f9a592409b7200da3d8bc04290d73a0370c260054500a05d21b699c632ffe | completed | pending_review | converged |
| e71301b6b55965b8245df65dc03ab4a7c871d601571e0f68afc544e8ee6bd00a | completed | pending_review | converged |

## Retrieval episodes

Measured: 2/2. Exact answer matches are provisional; final judgments require evidence review.

## Retrieval diagnostics

相关来源候选只定位来源容器；目录不等于正文。派发只证明内容进入请求，不证明模型已理解。
读取回执不证明正文已送达；完整有效搜索片段不需要额外 read。
负例按原查询、字段和分页范围审阅，不把查询无命中当成全库不存在。
observed=已出现，not_observed=本条轨迹未出现，unknown=未知，not_applicable=不适用。
pending_review=待人工审阅；provisional 匹配不是正式评分。

| 题目 ID | 相关来源候选 | 足够证据派发 | 回答评估 | 观测缺口 |
|---|---|---|---|---|
| s-direct | observed | observed | pending_review | evidence-dispatched |
| s-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
