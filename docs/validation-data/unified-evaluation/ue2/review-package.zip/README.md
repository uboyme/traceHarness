# Retrieval review

Read review.json and the original run evidence. Fill reviewer and judgments: trial_id, status (passed/failed/pending_review), reason. Missing judgments remain pending. Submit with traceh eval --assess. This export did not call a model or any tool.
