## Retrieval diagnostics

相关来源候选只定位来源容器；目录不等于正文。派发只证明内容进入请求，不证明模型已理解。
读取回执不证明正文已送达；完整有效搜索片段不需要额外 read。
负例按原查询、字段和分页范围审阅，不把查询无命中当成全库不存在。
observed=已出现，not_observed=本条轨迹未出现，unknown=未知，not_applicable=不适用。
pending_review=待人工审阅；provisional 匹配不是正式评分。

| 题目 ID | 相关来源候选 | 足够证据派发 | 回答评估 | 观测缺口 |
|---|---|---|---|---|
| mobile-specimen | observed | observed | passed | evidence-dispatched |
| restoration-room | observed | observed | failed | evidence-dispatched |
| stamp-catalog | not_applicable | not_applicable | passed | negative-scope-review |
| printshop-limit | observed | observed | failed | evidence-dispatched |
| geology-transfer | observed | observed | passed | evidence-dispatched |

```json
{
  "format": 1,
  "binding": {
    "run_id": "3aded73c-81ca-45d1-9af0-37730e74789b",
    "frozen_digest": "e2f0024d5ee903fa1250f4ecd52c4936883d553a20453024cedb153f6d3ed926",
    "evidence_digest": "c1df02f71c383eafc09b81e7ac18b773c3ac0c2970bf01c3f49aaf51d67d7fe3",
    "report_digest": "5807ea6e0585a62bcb8026b32ca8e610e3eb6e02470182cdb6c40b33b2ad581e",
    "scorer_id": "retrieval-evidence-v1",
    "scorer_version": 1,
    "rubric_digest": "60da87b9426407b8fe5af8a016a1388838346ec9c58c13b462171a220108d3d0"
  },
  "analyzer": {
    "version": 1,
    "source_digest": "5b51bbe4ce7aadf42baf2c5cf7a1f6ed292c314ed5eedd67e07833fd3ef8d493"
  },
  "rows": [
    {
      "trial_id": "f688dfda6ab95cf0189910dfdc2df29068576a59c6ad06e2b20b7038a7fd6246",
      "case_id": "mobile-specimen",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer correctly states the code 'LIME-274' and attributes it to the '流动标本车工作手册' skill document, specifically the '接收箱封签' section (mapped to section_id 'required-procedure'). The visible_evidence includes the exact excerpt: '标本车接收箱的封签必须打印 LIME-274。', which matches the expectation's source_text and value. The dispatched_evidence confirms this excerpt was retrieved via request_skill_reference with the correct catalog_digest, section_id, and tier='section'. No unsupported claims are made; the answer does not overstate scope (e.g., does not claim this is the only rule in the entire manual). All rubric requirements for a positive answer — correct value, proper attribution, evidence actually dispatched and visible, no extra unsupported claims — are satisfied."
      },
      "provisional_answer_match": true,
      "question": "流动标本车的接收箱封签应打印哪个代号？",
      "answer": "根据提供的技能文档（\"流动标本车工作手册\"）中“接收箱封签”章节的内容，流动标本车的接收箱封签必须打印 **LIME-274**。\n\n{\"代号\": \"LIME-274\"}",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "bf6841b7-c241-4d5c-a9d0-07a949778b38",
              "dispatch_fingerprint": "638abab629a5810b814f053dcfda071fc87e60df876c8aa1b1f057adfc0262ce",
              "context_seq": 7,
              "id": "mobile-specimen.manual",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "mobile-specimen.manual"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "90a5adae-ceca-44ff-babf-3010992548dc",
              "dispatch_fingerprint": "db55e6294e59d08c1fc06750699f387e0fe3768f1b1527f8f282517d5ce18be4",
              "context_seq": 20,
              "id": "mobile-specimen.manual",
              "version": "1.0.0",
              "tier": "section",
              "provenance": {
                "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": "required-procedure",
                "skill_id": "mobile-specimen.manual"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "90a5adae-ceca-44ff-babf-3010992548dc",
              "dispatch_fingerprint": "db55e6294e59d08c1fc06750699f387e0fe3768f1b1527f8f282517d5ce18be4",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "mobile-specimen.manual",
                "provenance": {
                  "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
                  "chunk_id": null,
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": null,
                  "section_id": "required-procedure",
                  "skill_id": "mobile-specimen.manual"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "bf6841b7-c241-4d5c-a9d0-07a949778b38",
            "dispatch_fingerprint": "638abab629a5810b814f053dcfda071fc87e60df876c8aa1b1f057adfc0262ce",
            "context_seq": 7,
            "id": "mobile-specimen.manual",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "mobile-specimen.manual"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "90a5adae-ceca-44ff-babf-3010992548dc",
            "dispatch_fingerprint": "db55e6294e59d08c1fc06750699f387e0fe3768f1b1527f8f282517d5ce18be4",
            "context_seq": 20,
            "id": "mobile-specimen.manual",
            "version": "1.0.0",
            "tier": "section",
            "provenance": {
              "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": "required-procedure",
              "skill_id": "mobile-specimen.manual"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_2ea4d6f2dd744280b3ee0c",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "e83ea9ea3f778851d0b07fcd019ac08cf9b96fac1152068dbc8c6c7cf6f283eb",
              "chunk_id": null,
              "requested_tier": "section",
              "resource_id": null,
              "section_id": "required-procedure",
              "skill_id": "mobile-specimen.manual",
              "version": "1.0.0"
            },
            "requested_tier": "section",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "b75d5eed602399ae36accc091eab63fa5c30988bd3f832d2b5c35d947d02f2d7",
      "case_id": "restoration-room",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "failed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer states both the口令 'RILL-682' and the action '按下蓝色隔离钮', but the expectation is strictly for the value 'RILL-682' (a code). The rubric requires positive answers to provide *only* the correct value and attribution, with *no unsupported extra claims*. Including 'and press the blue isolation button' is an unsupported extra claim relative to the expectation's scope — the expectation does not ask for or validate the button action. While the chunk text contains both pieces, the answer over-delivers beyond the expected single code value, violating the rubric's requirement of precision and no extra claims."
      },
      "provisional_answer_match": true,
      "question": "古籍修复室遇到烘干柜异常时，要报什么口令并按哪个按钮？",
      "answer": "根据提供的古籍修复室工作手册内容，当遇到烘干柜温湿异常时，值班员应报口令 **RILL-682**，并按下 **蓝色隔离钮**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "46b6f883-e5b4-45f0-8dd0-b17f90788b35",
              "dispatch_fingerprint": "e78b6e069f00585cbaa5d3fb6fc6bde998287b59a1b8a1527e6405d5c9c8ad10",
              "context_seq": 7,
              "id": "restoration-room.manual",
              "version": "1.0.0",
              "tier": "directory",
              "provenance": {
                "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
                "chunk_id": null,
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": null,
                "section_id": null,
                "skill_id": "restoration-room.manual"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "8d08b075-3afb-4bd8-882c-143cd33dd6da",
              "dispatch_fingerprint": "7a7a6c218a47d09dd5539fd45aa0b1345ec899f267a61008fed4612fd2614826",
              "context_seq": 20,
              "id": "restoration-room.manual",
              "version": "1.0.0",
              "tier": "chunk",
              "provenance": {
                "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
                "chunk_id": "procedure",
                "plugin": {
                  "plugin_id": "reference.author",
                  "version": "1.0.0"
                },
                "resource_id": "response-card",
                "section_id": null,
                "skill_id": "restoration-room.manual"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "8d08b075-3afb-4bd8-882c-143cd33dd6da",
              "dispatch_fingerprint": "7a7a6c218a47d09dd5539fd45aa0b1345ec899f267a61008fed4612fd2614826",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "restoration-room.manual",
                "provenance": {
                  "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
                  "chunk_id": "procedure",
                  "plugin": {
                    "plugin_id": "reference.author",
                    "version": "1.0.0"
                  },
                  "resource_id": "response-card",
                  "section_id": null,
                  "skill_id": "restoration-room.manual"
                },
                "source_refs": [],
                "version": "1.0.0"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "46b6f883-e5b4-45f0-8dd0-b17f90788b35",
            "dispatch_fingerprint": "e78b6e069f00585cbaa5d3fb6fc6bde998287b59a1b8a1527e6405d5c9c8ad10",
            "context_seq": 7,
            "id": "restoration-room.manual",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "restoration-room.manual"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "8d08b075-3afb-4bd8-882c-143cd33dd6da",
            "dispatch_fingerprint": "7a7a6c218a47d09dd5539fd45aa0b1345ec899f267a61008fed4612fd2614826",
            "context_seq": 20,
            "id": "restoration-room.manual",
            "version": "1.0.0",
            "tier": "chunk",
            "provenance": {
              "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
              "chunk_id": "procedure",
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": "response-card",
              "section_id": null,
              "skill_id": "restoration-room.manual"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_cf2eee966d1f438ca4c73d",
            "tool_name": "request_skill_reference",
            "arguments": {
              "catalog_digest": "80e2c34cdeb3918c9ad22e93b71204cfa1d4629ccb6b65bc647a9c65940f84ae",
              "chunk_id": "procedure",
              "requested_tier": "chunk",
              "resource_id": "response-card",
              "section_id": null,
              "skill_id": "restoration-room.manual",
              "version": "1.0.0"
            },
            "requested_tier": "chunk",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "b6e9fc7bc1bec96b3033d93282aca6ff182603edde49bb7e64c4ecfd1bdf4ed6",
      "case_id": "stamp-catalog",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer correctly concludes '否' (No) based solely on the visible navigation-only evidence: the skill directory metadata for 'stamp-catalog.manual' contains no title, summary, or tag referencing '停车券', '价格', or semantic equivalents; all sections are small (<77 bytes) and semantically about stamp cataloging and cleaning records; and the document's stated purpose ('邮票目录整理规范操作说明') is unrelated to parking vouchers. The rubric permits negative answers when a complete authoritative search excerpt (here, the full directory navigation) shows no relevant terms in metadata, and the answer avoids overclaiming — it does not assert the *entire document* lacks pricing info (which would require reading bodies), but correctly limits its claim to what the disclosed navigation metadata reveals. No evidence was dispatched beyond this directory view, matching the evidence_scope ('navigation-metadata-only'), and the answer aligns with the 'no-evidence' expectation."
      },
      "provisional_answer_match": null,
      "question": "邮票目录整理规范里写了停车券多少钱吗？",
      "answer": "邮票目录整理规范（`stamp-catalog.manual`）的目录结构已提供，其中包含一个主节“条目登记”（`required-procedure`）和多个“清洁登记”类小节（`routine-0` 至 `routine-9`），但**所有节摘要均未提及“停车券”或价格相关内容**。\n\n该 Skill 文档定位为“邮票目录整理规范操作说明”，主题聚焦于邮票条目登记与清洁记录流程，与停车券定价无语义关联。且当前披露的导航元数据中：\n- 无任何 section 或 resource 的 `title`、`summary`、`tags` 包含 “停车券”、“停车”、“券”、“price”、“费用”、“多少钱” 等关键词；\n- `content_bytes` 均极小（51–77 字节），表明内容高度精简，不支持隐含定价信息；\n- 未提供实际正文内容（`body_status: \"navigation-only\"`），但导航本身已足够否定相关性。\n\n因此，**邮票目录整理规范里没有写停车券多少钱**。\n\n答案：否。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "not_applicable",
          "granularity": "source-container",
          "observations": []
        },
        "evidence": {
          "status": "not_applicable",
          "observations": []
        },
        "gap": "negative-scope-review",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "c28f5004-0040-49ce-85d3-2fd069bdb0df",
            "dispatch_fingerprint": "596f7c4fb541a31c03ec30ac2c21ff48de0ca0d5d93f78bd515698055ff5785c",
            "context_seq": 7,
            "id": "stamp-catalog.manual",
            "version": "1.0.0",
            "tier": "directory",
            "provenance": {
              "catalog_digest": "aba7e659d754c4819f49fdead1ccdc52b213bfa125e46e731689e0afd3493f2e",
              "chunk_id": null,
              "plugin": {
                "plugin_id": "reference.author",
                "version": "1.0.0"
              },
              "resource_id": null,
              "section_id": null,
              "skill_id": "stamp-catalog.manual"
            }
          }
        ],
        "read_requests": [],
        "search_coverage": [],
        "negative_scope_review_required": true,
        "successful_answer_dispatches": 1,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "d395b9f5a6ef78f92bf47c125ba88125bb7493d32d93f1d6a342d34c14a950f2",
      "case_id": "printshop-limit",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "failed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer is '共享印制车间获批的同时入场上限为 27 人。', but the expectation requires a numeric value '27' (value_type: number). The answer returns a full Chinese sentence, not the extracted number. It fails the 'correct value' requirement of the rubric: positive answers must provide the exact expected value type — here, a bare number — and not a natural-language restatement. Attribution and evidence dispatch are satisfied (section body matches), but the format violation is fatal."
      },
      "provisional_answer_match": true,
      "question": "共享印制车间批准的同时入场人数是多少？",
      "answer": "共享印制车间获批的同时入场上限为 27 人。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 10,
              "attempt_id": "a44df457-fbe8-4df9-b41d-dcd2295c9c01",
              "dispatch_fingerprint": "9892c6e209867da90c33a34a6542531697ba1278ccba5b1f702bfe5599586801",
              "context_seq": 7,
              "id": "printshop.capacity",
              "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
              "tier": "directory",
              "provenance": {
                "activation_ref": {
                  "digest": "382d43c9a1fe6c2d49469a30153b9c563e651394ea7c20ab3febaaa47891ce61",
                  "event_id": "1e1997f6-8ce0-410f-ba8f-6fd74da5932f",
                  "seq": 2,
                  "stream_id": "memory:printshop",
                  "type": "memory/approved"
                },
                "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
                "fact_slot": "capacity",
                "memory_id": "printshop.capacity",
                "project_id": "printshop"
              }
            },
            {
              "request_snapshot_seq": 23,
              "attempt_id": "544a4b59-b67d-4acc-8be2-3ebd39c87976",
              "dispatch_fingerprint": "9a53965d8f22b444829029ce2552813181b882ea6cfebe8e4712eb106683cf9a",
              "context_seq": 20,
              "id": "printshop.capacity",
              "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
              "tier": "section",
              "provenance": {
                "activation_ref": {
                  "digest": "382d43c9a1fe6c2d49469a30153b9c563e651394ea7c20ab3febaaa47891ce61",
                  "event_id": "1e1997f6-8ce0-410f-ba8f-6fd74da5932f",
                  "seq": 2,
                  "stream_id": "memory:printshop",
                  "type": "memory/approved"
                },
                "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
                "fact_slot": "capacity",
                "memory_id": "printshop.capacity",
                "project_id": "printshop"
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 23,
              "attempt_id": "544a4b59-b67d-4acc-8be2-3ebd39c87976",
              "dispatch_fingerprint": "9a53965d8f22b444829029ce2552813181b882ea6cfebe8e4712eb106683cf9a",
              "context_seq": 20,
              "tool_result_seq": null,
              "reference": {
                "id": "printshop.capacity",
                "provenance": {
                  "activation_ref": {
                    "digest": "382d43c9a1fe6c2d49469a30153b9c563e651394ea7c20ab3febaaa47891ce61",
                    "event_id": "1e1997f6-8ce0-410f-ba8f-6fd74da5932f",
                    "seq": 2,
                    "stream_id": "memory:printshop",
                    "type": "memory/approved"
                  },
                  "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
                  "fact_slot": "capacity",
                  "memory_id": "printshop.capacity",
                  "project_id": "printshop"
                },
                "source_refs": [
                  {
                    "digest": "c8db04eac607659f4c5bbdc424ec2b675e2d6bcb313b4e13529d8e1a3619bb9c",
                    "event_id": "7dc0194e-ce10-4f0b-9cf8-de3a653135e6",
                    "seq": 1,
                    "stream_id": "memory:printshop",
                    "type": "memory/proposed"
                  },
                  {
                    "digest": "382d43c9a1fe6c2d49469a30153b9c563e651394ea7c20ab3febaaa47891ce61",
                    "event_id": "1e1997f6-8ce0-410f-ba8f-6fd74da5932f",
                    "seq": 2,
                    "stream_id": "memory:printshop",
                    "type": "memory/approved"
                  }
                ],
                "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 10,
            "attempt_id": "a44df457-fbe8-4df9-b41d-dcd2295c9c01",
            "dispatch_fingerprint": "9892c6e209867da90c33a34a6542531697ba1278ccba5b1f702bfe5599586801",
            "context_seq": 7,
            "id": "printshop.capacity",
            "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
            "tier": "directory",
            "provenance": {
              "activation_ref": {
                "digest": "382d43c9a1fe6c2d49469a30153b9c563e651394ea7c20ab3febaaa47891ce61",
                "event_id": "1e1997f6-8ce0-410f-ba8f-6fd74da5932f",
                "seq": 2,
                "stream_id": "memory:printshop",
                "type": "memory/approved"
              },
              "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
              "fact_slot": "capacity",
              "memory_id": "printshop.capacity",
              "project_id": "printshop"
            }
          },
          {
            "request_snapshot_seq": 23,
            "attempt_id": "544a4b59-b67d-4acc-8be2-3ebd39c87976",
            "dispatch_fingerprint": "9a53965d8f22b444829029ce2552813181b882ea6cfebe8e4712eb106683cf9a",
            "context_seq": 20,
            "id": "printshop.capacity",
            "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6",
            "tier": "section",
            "provenance": {
              "activation_ref": {
                "digest": "382d43c9a1fe6c2d49469a30153b9c563e651394ea7c20ab3febaaa47891ce61",
                "event_id": "1e1997f6-8ce0-410f-ba8f-6fd74da5932f",
                "seq": 2,
                "stream_id": "memory:printshop",
                "type": "memory/approved"
              },
              "approved_content_digest": "891f0bca5cd6063d683a5dea04f2125b48aac73bfd63422fbac345bb44c75a29",
              "fact_slot": "capacity",
              "memory_id": "printshop.capacity",
              "project_id": "printshop"
            }
          }
        ],
        "read_requests": [
          {
            "call_seq": 15,
            "tool_call_id": "call_d42989aafc4247f381d188",
            "tool_name": "request_workspace_memory",
            "arguments": {
              "memory_id": "printshop.capacity",
              "requested_tier": "section",
              "version": "a83b99580c6cea9f86da2108bcc9a41e903365fd5a2f2dc8057ee11a8cd7bfc6"
            },
            "requested_tier": "section",
            "result_seq": 17,
            "status": "succeeded",
            "error_type": null
          }
        ],
        "search_coverage": [],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    },
    {
      "trial_id": "2819876cbec00511674103be2d61083e22cc6f4a1c0cb7578479446b5e60b18c",
      "case_id": "geology-transfer",
      "execution": {
        "reason": null,
        "status": "completed"
      },
      "assessment": {
        "status": "passed",
        "reviewer": "model:openai-compatible/qwen-plus",
        "origin": "model",
        "reason": "The candidate answer correctly extracts and states the submission batch flag 'KITE-905' and handover point '西拱门第二排' from the dispatched evidence — specifically, the visible search hit containing the exact string '临时地质展的新提交批次标志为 KITE-905，交接点设在西拱门第二排。'. This matches the expectation's required value ('KITE-905') and value_type ('code'). The answer attributes the information to '历史记录中有一条明确的信息', which is accurate: the evidence is from a history record (user/message, seq=21), and the search coverage confirms two hits in indexed history records, with one explicitly containing the target string. No unsupported claims are made; the answer does not overstate scope (e.g., no claim of global uniqueness or exhaustiveness beyond the searched history). The evidence was dispatched before answering, and the search coverage (scanned=6, total=6, next_cursor=null) indicates full coverage of the indexed history window for the query '临时地质展'. Thus, all rubric requirements for a positive answer are satisfied."
      },
      "provisional_answer_match": true,
      "question": "之前临时地质展说的提交批次标志和交接点是什么？",
      "answer": "根据搜索结果，我找到了关于临时地质展的提交批次标志和交接点的信息。\n\n在历史记录中有一条明确的信息：\"临时地质展的新提交批次标志为 KITE-905，交接点设在西拱门第二排。\"\n\n因此，临时地质展的提交批次标志是 **KITE-905**，交接点是 **西拱门第二排**。",
      "observation": {
        "format": 1,
        "candidate": {
          "status": "observed",
          "granularity": "source-container",
          "observations": [
            {
              "request_snapshot_seq": 56,
              "attempt_id": "f2694c19-5e28-4782-b1d0-5293fb19981b",
              "dispatch_fingerprint": "8a7ddca6a2482f3c400959ff7d0b44851e33861d0a7e8e47ed3bb5f25ff4f9e6",
              "context_seq": 53,
              "id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
              "version": "e5f23063c511a8242704b794d5d9835b5e3e9597b34b477b14aa101b1d7fb26f",
              "tier": "directory",
              "provenance": {
                "block_id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
                "freshness": "unknown",
                "observed_at": "2026-09-10T18:37:16.261659+00:00",
                "observed_through_seq": 46,
                "page": null,
                "request_ref": null,
                "workspace_observation": null
              }
            },
            {
              "request_snapshot_seq": 69,
              "attempt_id": "e2b70cd1-eb4d-47c6-ac16-11f117d22c17",
              "dispatch_fingerprint": "c03a56d529b319062866f0b243e7f6c838fa0d5a1b0afe060d781f01d1979b7d",
              "context_seq": 66,
              "id": "9b59e0847f86212d351eea580a02fcef90d79be7dc44f71eb43f4bfa25084d05",
              "version": "874a49158441080a4f11536bde577d1b16e69bec95bf4a370de87615b294f8bc",
              "tier": "search",
              "provenance": {
                "policy_digest": "a6885a0cb2c5e2fd6536e39d7765191293c2e7711cea531bbc08ebbd3532450b",
                "request_ref": {
                  "digest": "23e40c22656c130698a02e20cd765a2b84504afb075e3213859c53950c65570d",
                  "event_id": "3ad05820-3626-4ece-8050-a3ce11611c0b",
                  "seq": 63,
                  "stream_id": "session:7b90d639-e55a-4d9c-8ecc-6e5445dff794",
                  "type": "tool/result"
                },
                "source_digest": "874a49158441080a4f11536bde577d1b16e69bec95bf4a370de87615b294f8bc"
              }
            },
            {
              "request_snapshot_seq": 69,
              "attempt_id": "e2b70cd1-eb4d-47c6-ac16-11f117d22c17",
              "dispatch_fingerprint": "c03a56d529b319062866f0b243e7f6c838fa0d5a1b0afe060d781f01d1979b7d",
              "context_seq": 66,
              "id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
              "version": "e5f23063c511a8242704b794d5d9835b5e3e9597b34b477b14aa101b1d7fb26f",
              "tier": "directory",
              "provenance": {
                "block_id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
                "freshness": "unknown",
                "observed_at": "2026-09-10T18:37:16.261659+00:00",
                "observed_through_seq": 46,
                "page": null,
                "request_ref": null,
                "workspace_observation": null
              }
            }
          ]
        },
        "evidence": {
          "status": "observed",
          "observations": [
            {
              "request_snapshot_seq": 69,
              "attempt_id": "e2b70cd1-eb4d-47c6-ac16-11f117d22c17",
              "dispatch_fingerprint": "c03a56d529b319062866f0b243e7f6c838fa0d5a1b0afe060d781f01d1979b7d",
              "context_seq": 66,
              "tool_result_seq": null,
              "reference": {
                "block_id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
                "cursor": {
                  "block_id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
                  "index": 0,
                  "policy_digest": "e173fd45286d53b81638648235db08d02c7dc184323cc9a6f80c1a4af51f810a"
                },
                "leaf_ref": {
                  "digest": "7a3652eeb131ac557df590116246f631377ad57d44516f116e784957ab676c11",
                  "event_id": "4f4b02bb-c82a-4e2c-a519-e7d023118582",
                  "seq": 21,
                  "stream_id": "session:7b90d639-e55a-4d9c-8ecc-6e5445dff794",
                  "type": "user/message"
                },
                "readable": true,
                "version": "e5f23063c511a8242704b794d5d9835b5e3e9597b34b477b14aa101b1d7fb26f"
              }
            }
          ]
        },
        "gap": "evidence-dispatched",
        "source_views": [
          {
            "request_snapshot_seq": 56,
            "attempt_id": "f2694c19-5e28-4782-b1d0-5293fb19981b",
            "dispatch_fingerprint": "8a7ddca6a2482f3c400959ff7d0b44851e33861d0a7e8e47ed3bb5f25ff4f9e6",
            "context_seq": 53,
            "id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
            "version": "e5f23063c511a8242704b794d5d9835b5e3e9597b34b477b14aa101b1d7fb26f",
            "tier": "directory",
            "provenance": {
              "block_id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
              "freshness": "unknown",
              "observed_at": "2026-09-10T18:37:16.261659+00:00",
              "observed_through_seq": 46,
              "page": null,
              "request_ref": null,
              "workspace_observation": null
            }
          },
          {
            "request_snapshot_seq": 69,
            "attempt_id": "e2b70cd1-eb4d-47c6-ac16-11f117d22c17",
            "dispatch_fingerprint": "c03a56d529b319062866f0b243e7f6c838fa0d5a1b0afe060d781f01d1979b7d",
            "context_seq": 66,
            "id": "9b59e0847f86212d351eea580a02fcef90d79be7dc44f71eb43f4bfa25084d05",
            "version": "874a49158441080a4f11536bde577d1b16e69bec95bf4a370de87615b294f8bc",
            "tier": "search",
            "provenance": {
              "policy_digest": "a6885a0cb2c5e2fd6536e39d7765191293c2e7711cea531bbc08ebbd3532450b",
              "request_ref": {
                "digest": "23e40c22656c130698a02e20cd765a2b84504afb075e3213859c53950c65570d",
                "event_id": "3ad05820-3626-4ece-8050-a3ce11611c0b",
                "seq": 63,
                "stream_id": "session:7b90d639-e55a-4d9c-8ecc-6e5445dff794",
                "type": "tool/result"
              },
              "source_digest": "874a49158441080a4f11536bde577d1b16e69bec95bf4a370de87615b294f8bc"
            }
          },
          {
            "request_snapshot_seq": 69,
            "attempt_id": "e2b70cd1-eb4d-47c6-ac16-11f117d22c17",
            "dispatch_fingerprint": "c03a56d529b319062866f0b243e7f6c838fa0d5a1b0afe060d781f01d1979b7d",
            "context_seq": 66,
            "id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
            "version": "e5f23063c511a8242704b794d5d9835b5e3e9597b34b477b14aa101b1d7fb26f",
            "tier": "directory",
            "provenance": {
              "block_id": "44b9ae66c9ed5ff30c8448d89645597d20e961491bcb0d336e94a32b006c4257",
              "freshness": "unknown",
              "observed_at": "2026-09-10T18:37:16.261659+00:00",
              "observed_through_seq": 46,
              "page": null,
              "request_ref": null,
              "workspace_observation": null
            }
          }
        ],
        "read_requests": [],
        "search_coverage": [
          {
            "request_snapshot_seq": 69,
            "attempt_id": "e2b70cd1-eb4d-47c6-ac16-11f117d22c17",
            "dispatch_fingerprint": "c03a56d529b319062866f0b243e7f6c838fa0d5a1b0afe060d781f01d1979b7d",
            "context_seq": 66,
            "id": "9b59e0847f86212d351eea580a02fcef90d79be7dc44f71eb43f4bfa25084d05",
            "version": "874a49158441080a4f11536bde577d1b16e69bec95bf4a370de87615b294f8bc",
            "tier": "search",
            "provenance": {
              "policy_digest": "a6885a0cb2c5e2fd6536e39d7765191293c2e7711cea531bbc08ebbd3532450b",
              "request_ref": {
                "digest": "23e40c22656c130698a02e20cd765a2b84504afb075e3213859c53950c65570d",
                "event_id": "3ad05820-3626-4ece-8050-a3ce11611c0b",
                "seq": 63,
                "stream_id": "session:7b90d639-e55a-4d9c-8ecc-6e5445dff794",
                "type": "tool/result"
              },
              "source_digest": "874a49158441080a4f11536bde577d1b16e69bec95bf4a370de87615b294f8bc"
            },
            "domain": "history",
            "query": "临时地质展",
            "fields": [
              "message.content"
            ],
            "status": "matches",
            "scanned": 6,
            "total": 6,
            "next_cursor": null,
            "hit_count": 2,
            "proves_global_absence": false
          }
        ],
        "negative_scope_review_required": false,
        "successful_answer_dispatches": 2,
        "execution_failure": null,
        "execution_reason": "completed"
      }
    }
  ]
}
```
