"""Interactive multi-turn chat loop.

The loop owns no conversation state. Every turn goes through
``AgentRuntime.run_existing()``, so the Session event log stays the single
source of truth and the model history is projected from it, exactly as for the
one-shot commands. What lives here is only terminal behaviour: prompting,
internal commands, rendering a turn result and converging on exit.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import urlparse

from traceh.chat.activity import (
    ActivityPhase,
    ActivityUpdate,
    Clock,
    default_clock,
)
from traceh.chat.driver import (
    ChatDriver,
    ChatUpdate,
    SessionEventUpdate,
    TurnCompletedUpdate,
    TurnFailedUpdate,
    TurnInterruptedUpdate,
)
from traceh.chat.session import ChatSession, open_chat_session
from traceh.cli.activity import DEFAULT_HEARTBEAT_SECONDS, render_activity_wait
from traceh.cli.command_line import (
    Literal,
    UnsafeCommandValue,
    default_shell,
    escape_for_display,
    is_renderable,
    render_command,
)
from traceh.cli.console import Console, contains_undecodable_input, normalize_input
from traceh.cli.env_file import is_env_var_name
from traceh.cli.errors import CliConfigurationError
from traceh.cli.timeline import TimelineRenderer, sanitize
from traceh.runtime.agent_runtime import AgentRuntime
from traceh.session.protocol import SessionProtocolError
from traceh.session.service import SessionNotFoundError

if TYPE_CHECKING:
    from traceh.cli.product import LineProductAdapter
    from traceh.product.chat import ProductChatTurn

PROMPT = "you> "
ASSISTANT_PREFIX = "assistant> "

#: Conventional shell exit code for "terminated by SIGINT".
INTERRUPTED_EXIT_CODE = 130

#: Shown after a turn is interrupted, to make clear the session survived.
INTERRUPTED_TURN_NOTICE = "Turn interrupted. This session is still open."

#: Printed once at startup when the timeline is on. Without it the first line
#: reads `[event 4]` and looks like something was lost; the real reason is that
#: `session/created`, `inbox/accepted` and `inbox/claimed` are persisted but not
#: displayed. Renumbering to 1 would destroy the property that makes the number
#: useful - being the seq you can look up in the durable event log.
#: Note the wording never *begins* with the bracket: a line starting with
#: `[event ...]` is a timeline row, and an explanation that imitates one would be
#: the first thing to confuse both a reader and a log filter.
_SEQ_NOTE_LINES = (
    "Timeline shows selected persisted events.",
    "Numbers shown as [event N] are Event Log seq values; they may start above 1 "
    "or skip where internal events are hidden.",
)

_HELP_LINES = (
    "/help     show these commands",
    "/session  show the session id, workspace, provider, model and resume command",
    "/sandbox  查看当前沙箱策略和本会话实际执行回执",
    "/task inspect TASK_ID    inspect a durable ProductTask (with --product-config)",
    "/task approve TASK_ID    approve and promote a verified ProductTask",
    "/task reject TASK_ID     reject without moving the target ref",
    "/task cancel TASK_ID     cancel owned work and release resources",
    "/task abandon TASK_ID    record an unowned interrupted task as abandoned",
    "/exit     leave the chat",
    "/quit     leave the chat",
    "",
    "Install plugins outside chat, then inspect and enable them here:",
    "  python -m pip install <plugin-wheel-or-package>",
    "  traceh plugins list",
    "  traceh plugins doctor ID",
    "",
    "Startup flags, not commands you can type here:",
    "  --no-timeline          silence live activity output",
    "  --heartbeat-seconds N  seconds between waiting notices (0 disables)",
)


@dataclass(frozen=True, slots=True)
class ResumeEnvironment:
    """Settings the resume command needs but `RuntimeConfig` does not carry.

    A resume command holding only a session id and a data dir looks sufficient
    and is not: provider and model may have come from a `.env` that the next
    shell will not find, so re-running it can silently continue the session on a
    different model.

    ``api_key_env`` is the *name* of the variable holding the key; the value is
    never read here and never printed. ``env_file_supplies`` lists the variables
    the env file actually applied, which is how the block can tell "this will be
    reloaded for you" from "you must supply this again" for the key itself.

    ``verifier_from_env_file`` is a **provenance flag, not the command**. Whether
    the env file can restore the verifier depends on which value actually won:
    an explicit ``--verify-command`` overrides the file, so the file containing
    that key proves nothing. Only argument resolution knows the answer, so it is
    decided there and passed here as a boolean. The verifier text itself is
    deliberately absent from this dataclass, keeping it out of the repr, the
    command and any log line.
    """

    base_url: str | None = None
    api_key_env: str | None = None
    env_file: Path | None = None
    script: Path | None = None
    env_file_supplies: frozenset[str] = frozenset()
    verifier_from_env_file: bool = False
    product_config: Path | None = None
    context_config: Path | None = None
    sandbox_config: Path | None = None


def _safe_base_url(value: str | None) -> tuple[str | None, str | None]:
    """Return the URL to display, or ``None`` plus the reason it was withheld.

    A base URL can carry credentials in two structural places, and both are
    checked by parsing rather than by pattern-matching the string: ``userinfo``
    (``https://user:password@host``) and the query string. Withholding on *any*
    query is deliberate - it needs no judgement about which parameter names are
    sensitive, and a base URL with a query is rare enough that refusing is
    cheaper than being wrong.

    This is a structural rule, not a secret detector: it cannot know whether an
    ordinary-looking path segment is itself a credential.
    """

    if not value:
        return None, None
    if not is_renderable(value):
        return None, "it contains control characters"
    try:
        parsed = urlparse(value)
        # Both the parse and the userinfo accessors can raise: `https://[bad`
        # fails with "Invalid IPv6 URL" only once the netloc is inspected.
        has_userinfo = bool(parsed.username or parsed.password)
    except ValueError:
        # An unparseable URL is withheld rather than echoed. It cannot be shown
        # to be credential-free, and reporting it would put the original value -
        # and a traceback - in front of the user.
        return None, "it could not be parsed as a URL"
    if has_userinfo:
        return None, "it embeds credentials in the URL"
    if parsed.query or parsed.fragment:
        return None, "it carries a query string that may contain credentials"
    return value, None


def chat_target(workspace: Path | None, session_id: str | None) -> tuple[Path | None, str | None]:
    """Validate that exactly one of workspace / session id was requested."""

    if workspace is not None and session_id is not None:
        raise CliConfigurationError("chat takes either a workspace or --session-id, not both")
    if workspace is None and session_id is None:
        raise CliConfigurationError(
            "chat needs a workspace to start a new session, or --session-id to continue one"
        )
    return workspace, session_id


async def run_chat(
    runtime: AgentRuntime,
    console: Console,
    *,
    workspace: Path | None = None,
    session_id: str | None = None,
    timeline: bool = True,
    heartbeat_seconds: float = DEFAULT_HEARTBEAT_SECONDS,
    clock: Clock | None = None,
    resume_environment: ResumeEnvironment | None = None,
    product: LineProductAdapter | None = None,
) -> int:
    """Open or continue a session, then read turns until the user leaves."""

    workspace, session_id = chat_target(workspace, session_id)
    resolved_clock = clock or default_clock()
    environment = resume_environment or ResumeEnvironment()
    interval = heartbeat_seconds if timeline else 0.0
    try:
        session = await _open_session(
            runtime,
            console,
            workspace=workspace,
            session_id=session_id,
            timeline=timeline,
            resume_environment=environment,
        )
        try:
            return await _chat_loop(
                runtime,
                console,
                session,
                timeline=timeline,
                heartbeat_seconds=interval,
                clock=resolved_clock,
                resume_environment=environment,
                product=product,
            )
        except (KeyboardInterrupt, asyncio.CancelledError):
            # Reached only for an interrupt the loop did not already absorb - an
            # idle Ctrl+C returns from the loop itself, and an interrupted turn
            # converges inside `_run_turn`. This is the top-level coroutine of
            # the process, so turning what is left into an exit code is the job.
            await _converge_interrupted(runtime, console, session, environment)
            return INTERRUPTED_EXIT_CODE
    finally:
        failures: list[BaseException] = []
        if product is not None:
            try:
                await product.aclose()
            except BaseException as error:
                failures.append(error)
        try:
            await runtime.dispose()
        except BaseException as error:
            failures.append(error)
        if failures:
            raise BaseExceptionGroup("chat shutdown failed", failures)


async def _open_session(
    runtime: AgentRuntime,
    console: Console,
    *,
    workspace: Path | None,
    session_id: str | None,
    timeline: bool,
    resume_environment: ResumeEnvironment,
) -> ChatSession:
    try:
        opened = await open_chat_session(
            runtime,
            workspace=workspace,
            session_id=session_id,
        )
    except NotADirectoryError as error:
        raise CliConfigurationError(f"workspace is not a directory: {error}") from error
    except SessionNotFoundError as error:
        raise CliConfigurationError(f"session not found: {session_id}") from error
    except SessionProtocolError as error:
        raise CliConfigurationError(
            "旧版会话协议无法继续。请使用新的数据目录和新会话；旧记录原样保留，"
            "不会自动迁移或删除。"
        ) from error
    session = opened.session
    await _write_session_banner(runtime, console, session, resume_environment)
    _write_seq_note(console, timeline=timeline)
    report = opened.recovery
    if report is not None and report.changed:
        console.write(
            "recovered: "
            f"model_attempts={report.closed_model_attempts} "
            f"tool_results={report.synthesized_tool_results} "
            f"step={report.closed_step} turn={report.closed_turn}"
        )
    return session


async def _chat_loop(
    runtime: AgentRuntime,
    console: Console,
    session: ChatSession,
    *,
    timeline: bool,
    heartbeat_seconds: float,
    clock: Clock,
    resume_environment: ResumeEnvironment,
    product: LineProductAdapter | None = None,
) -> int:
    console.write("Type /help for commands, /exit to leave.")
    while True:
        try:
            line = console.read_line(PROMPT)
        except EOFError:
            console.write("")
            await _write_resume_block_for_session(runtime, console, session, resume_environment)
            return 0
        except (KeyboardInterrupt, asyncio.CancelledError):
            # Idle interrupt: there is no turn to converge, so leaving is the
            # honest response. The resume block is reprinted because this is the
            # moment the user most needs it.
            console.write("")
            await _write_resume_block_for_session(runtime, console, session, resume_environment)
            return INTERRUPTED_EXIT_CODE

        text = normalize_input(line)
        if not text:
            continue
        if contains_undecodable_input(text):
            console.write(
                "input contains characters that could not be decoded and was not sent. "
                "Send the text as UTF-8; TraceHarness will not guess what it was."
            )
            continue
        if text.startswith("/"):
            if await _handle_command(
                runtime,
                console,
                session,
                text,
                resume_environment,
                product=product,
            ):
                await _write_resume_block_for_session(runtime, console, session, resume_environment)
                return 0
            continue
        interrupted_twice = await _run_turn(
            runtime,
            console,
            session,
            text,
            timeline=timeline,
            heartbeat_seconds=heartbeat_seconds,
            clock=clock,
            product=product,
        )
        if interrupted_twice:
            # The user asked again while the first interrupt was still
            # converging. Convergence finished first; now honour the second ask.
            await _write_resume_block_for_session(runtime, console, session, resume_environment)
            return INTERRUPTED_EXIT_CODE


async def _handle_command(
    runtime: AgentRuntime,
    console: Console,
    session: ChatSession,
    text: str,
    resume_environment: ResumeEnvironment,
    *,
    product: LineProductAdapter | None = None,
) -> bool:
    """Handle one internal command. Returns True when the chat should end."""

    if text in {"/exit", "/quit"}:
        return True
    if product is not None and await product.handle_command(text, console):
        return False
    if text == "/help":
        for entry in _HELP_LINES:
            console.write(entry)
        from traceh.chat.governance import HELP

        for entry in HELP:
            console.write(entry)
        return False
    if text == "/session":
        await _write_session_banner(runtime, console, session, resume_environment)
        return False
    if text == "/sandbox":
        from traceh.chat.sandbox_inspection import sandbox_report

        try:
            configuration = runtime.config.sandbox
            console.write(await sandbox_report(
                runtime.sessions.store, session_id=session.session_id,
                policy=configuration.policy if configuration is not None else None,
            ))
        except (ValueError, KeyError, TypeError):
            console.write("沙箱证据无法核对；未执行任何命令。")
        return False
    from traceh.chat.governance import ChatGovernance, display, handles

    if handles(text):

        async def confirm(review):
            console.write(display(review))
            try:
                answer = console.read_line("Type CONFIRM to apply; anything else cancels: ")
                return answer == "CONFIRM"
            except EOFError:
                return False

        try:
            result = await ChatGovernance(runtime, session.session_id).run(text, confirm=confirm)
            console.write(display(result))
        except Exception:
            console.write("governance operation failed; inspect current facts before retrying")
        return False
    console.write("unknown command (try /help)")
    return False


async def _run_turn(
    runtime: AgentRuntime,
    console: Console,
    session: ChatSession,
    text: str,
    *,
    timeline: bool,
    heartbeat_seconds: float,
    clock: Clock,
    product: LineProductAdapter | None = None,
) -> bool:
    """Submit one Turn to the UI-neutral driver and render typed updates."""

    adapter = _LineUpdateAdapter(console)
    driver = ChatDriver(
        runtime,
        session.session_id,
        sink=adapter.consume,
        timeline=timeline,
        heartbeat_seconds=heartbeat_seconds,
        clock=clock,
    )

    prepared: ProductChatTurn | None = None
    task_input = text
    if product is not None:
        prepared = await product.prepare_turn(session.session_id, text)
        task_input = prepared.turn_input

    outcome = await driver.run_turn(task_input)
    if outcome.result is None:
        if product is not None:
            await product.discard_turn(session.session_id, None)
        return outcome.leave_after_convergence
    result = outcome.result
    if product is not None:
        assert prepared is not None
        await product.finish_turn(
            session.session_id,
            prepared,
            turn_id=result.turn_id,
            console=console,
            heartbeat_seconds=heartbeat_seconds,
            clock=clock,
        )
    return outcome.leave_after_convergence


class _LineUpdateAdapter:
    """The first ChatDriver adapter: typed updates to existing Line output."""

    __slots__ = ("_console", "_timeline")

    def __init__(self, console: Console) -> None:
        self._console = console
        self._timeline = TimelineRenderer()

    async def consume(self, update: ChatUpdate) -> None:
        if isinstance(update, SessionEventUpdate):
            elapsed = (
                None
                if update.completed_activity is None
                else update.completed_activity.elapsed_seconds
            )
            line = self._timeline.render(update.event, elapsed_seconds=elapsed)
            if line is not None:
                self._console.write(line)
            return
        if isinstance(update, ActivityUpdate):
            if update.phase is ActivityPhase.WAITING:
                self._console.write(render_activity_wait(update))
            return
        if isinstance(update, TurnCompletedUpdate):
            _write_turn_result(self._console, update.result)
            return
        if isinstance(update, TurnFailedUpdate):
            if update.context_limit_exceeded:
                from traceh.cli.context_pressure import context_pressure_text

                self._console.write(context_pressure_text(update.context_pressure))
                return
            error_type = sanitize(update.error_type) or "Error"
            message = sanitize(update.message) or "error"
            self._console.write(f"error: {error_type}: {message}")
            return
        if isinstance(update, TurnInterruptedUpdate):
            self._console.write(INTERRUPTED_TURN_NOTICE)


def _write_turn_result(console: Console, result) -> None:
    console.write(f"{ASSISTANT_PREFIX}{result.final_text}")
    console.write(
        f"[reason={result.reason} steps={result.steps} "
        f"tokens={result.usage.total_tokens} verification={result.verification_passed}]"
    )


async def _converge_interrupted(
    runtime: AgentRuntime,
    console: Console,
    session: ChatSession,
    resume_environment: ResumeEnvironment,
) -> None:
    console.write("")
    await runtime.cancel(session.session_id, reason="interrupted from the chat console")
    await _write_resume_block_for_session(runtime, console, session, resume_environment)


async def _write_session_banner(
    runtime: AgentRuntime,
    console: Console,
    session: ChatSession,
    resume_environment: ResumeEnvironment | None = None,
) -> None:
    console.write(
        f"session_id={session.session_id} workspace={session.workspace} "
        f"provider={runtime.config.provider} model={runtime.config.model}"
    )
    await _write_resume_block_for_session(runtime, console, session, resume_environment)


async def _write_resume_block_for_session(
    runtime: AgentRuntime,
    console: Console,
    session: ChatSession,
    resume_environment: ResumeEnvironment | None = None,
) -> None:
    """Print a resume hint from the Session's durable plugin identity."""

    try:
        plugin_ids = await runtime.persisted_external_plugin_ids(session.session_id)
    except Exception:
        # A failed or malformed identity read must not turn the current
        # Generation into a false recovery instruction.  Keep only inert,
        # escaped locator data and omit the command until the Session can be
        # inspected safely.
        _write_resume_block(
            runtime,
            console,
            session,
            resume_environment,
            plugin_ids=(),
            omit_command=True,
        )
        return
    _write_resume_block(
        runtime,
        console,
        session,
        resume_environment,
        plugin_ids=plugin_ids,
    )


def _write_resume_block(
    runtime: AgentRuntime,
    console: Console,
    session: ChatSession,
    resume_environment: ResumeEnvironment | None = None,
    *,
    shell: str | None = None,
    plugin_ids: Sequence[str],
    omit_command: bool = False,
) -> None:
    """Print a copy-pasteable way back into this session.

    Printed at startup rather than only on exit, and that is the design: a hard
    interrupt - Ctrl+Break, closing the console - runs no Python at all, so an
    exit-time hint can never be relied on. Printing it up front means the
    information is already in the user's scroll-back whatever happens next.

    The block is split along the line that actually matters to a reader:

    * **finding the session** needs the session id and the resolved absolute data
      dir - the store lives under it, so a session started with a custom
      ``--data-dir`` or from another working directory cannot be reopened without
      it;
    * **restoring how it behaved** needs provider, model and the rest, because
      those may have come from a `.env` in the original working directory. A
      command carrying only the session id would re-resolve them wherever it runs
      and silently continue on a different model.

    It is deliberately **not** a complete configuration snapshot, and says so
    when it withholds something. Two values are never echoed verbatim:

    * ``--verify-command`` is arbitrary shell text. There is no way to show it and
      also promise it holds no credential, so it is omitted; when the env file
      supplied it, reloading that file restores it, and otherwise the user is told
      to re-supply it.
    * a base URL is withheld when it structurally carries credentials - see
      `_safe_base_url()`.

    Every value is placed in an argv token list and rendered once by
    `cli/command_line.py`, so shell metacharacters are quoted by that shell's own
    rule rather than by a shared guess.
    """

    environment = resume_environment or ResumeEnvironment()
    config = runtime.config
    data_dir = Path(config.data_dir).resolve()
    shell_name = shell or default_shell()

    if omit_command:
        console.write("resume later:")
        console.write(f"  session_id: {escape_for_display(session.session_id)}")
        console.write(f"  data dir:   {escape_for_display(str(data_dir))}")
        console.write(
            "  note: the Session's durable plugin identity could not be read safely; "
            "no resume command was printed."
        )
        return

    # Fixed literals stay bare so the command is runnable and readable; every
    # derived value goes through the renderer's quoting rule.
    locate: list[str] = [
        Literal("traceh"),
        Literal("chat"),
        Literal("--session-id"),
        session.session_id,
        Literal("--data-dir"),
        str(data_dir),
    ]
    restore: list[str] = [
        Literal("--provider"),
        str(config.provider),
        Literal("--model"),
        str(config.model),
    ]
    notes: list[str] = []

    if config.max_steps:
        restore += [Literal("--max-steps"), str(config.max_steps)]
    if config.repeated_denial_policy is None:
        restore += [Literal("--disable-repeated-denial-check")]
    else:
        restore += [Literal("--denial-warn-after"), str(config.repeated_denial_policy.warn_after),
                    Literal("--denial-stop-after"), str(config.repeated_denial_policy.stop_after)]

    retry = config.model_retry_policy
    restore += [
        Literal("--model-retry-max-attempts"),
        str(retry.max_attempts),
        Literal("--model-retry-max-elapsed-seconds"),
        str(retry.max_elapsed_seconds),
        Literal("--model-retry-base-delay-seconds"),
        str(retry.base_delay_seconds),
        Literal("--model-retry-max-delay-seconds"),
        str(retry.max_delay_seconds),
        Literal("--model-retry-after-cap-seconds"),
        str(retry.retry_after_cap_seconds),
        Literal("--model-retry-jitter-ratio"),
        str(retry.jitter_ratio),
    ]

    # Automatic compaction changes what a resumed Session may still show the
    # model, and it has no built-in default to fall back on. Omitting it would
    # silently turn the feature off for anyone who copied the command - the same
    # class of drift that made the provider/model tokens necessary. Every value
    # is a non-negative integer or a fixed literal, so nothing here can carry a
    # credential.
    compaction = config.compaction
    if config.token_budget is not None:
        budget = config.token_budget
        restore.extend(
            [
                Literal("--token-encoding"),
                budget.encoding,
                Literal("--context-window-tokens"),
                str(budget.window_tokens),
                Literal("--context-output-reserve"),
                str(budget.output_reserve_tokens),
                Literal("--context-safety-margin"),
                str(budget.safety_margin_tokens),
                Literal("--context-trigger-percent"),
                str(budget.trigger_percent),
            ]
        )
    if compaction is not None and compaction.enabled:
        restore += [
            Literal("--auto-compact"),
            Literal("on"),
            Literal("--auto-compact-bytes"),
            str(compaction.trigger_utf8_bytes),
            Literal("--auto-compact-summary-bytes"),
            str(compaction.max_summary_utf8_bytes),
            Literal("--auto-compact-keep-turns"),
            str(compaction.keep_recent_turns),
        ]
        restore += [
            Literal("--auto-compact-method"),
            "semantic" if config.semantic_summary else "extractive",
        ]

    if config.verifier_name is not None:
        restore += [Literal("--plugin-verifier"), config.verifier_name]

    # Without these the resumed session would be refused by the plugin identity
    # check - correctly, but with no hint about what to re-enable.
    for plugin_id in plugin_ids:
        restore += [Literal("--plugin"), plugin_id]

    if environment.script is not None:
        restore += [Literal("--script"), str(Path(environment.script).resolve())]
        notes.append(
            "  note: --script replays the same file from its first response; "
            "the scripted cursor is not persisted across processes."
        )

    if environment.product_config is not None:
        restore += [
            Literal("--product-config"),
            str(Path(environment.product_config).resolve()),
        ]
    if environment.context_config is not None:
        restore += [Literal("--context-config"), str(Path(environment.context_config).resolve())]
    if environment.sandbox_config is not None:
        restore += [Literal("--sandbox-config"), str(Path(environment.sandbox_config).resolve())]

    base_url, withheld_reason = _safe_base_url(environment.base_url)
    if base_url:
        restore += [Literal("--base-url"), base_url]
    elif withheld_reason:
        notes.append(
            f"  note: --base-url omitted because {withheld_reason}; re-supply it manually."
        )

    # The key variable only matters to a provider that sends one. Naming
    # OPENAI_API_KEY for a scripted session would be noise at best and a
    # misleading instruction at worst.
    key_name = environment.api_key_env
    if key_name and config.provider != "scripted" and is_env_var_name(key_name):
        restore += [Literal("--api-key-env"), key_name]
        if key_name in environment.env_file_supplies:
            notes.append(
                f"  note: {key_name} must be available from that env file or the shell; "
                "its value is never printed."
            )
        else:
            notes.append(f"  note: set {key_name} in that shell; its value is never printed.")

    if environment.env_file is not None:
        restore += [Literal("--env-file"), str(Path(environment.env_file).resolve())]

    if config.verification_command:
        # The flag, not the presence of the key: an explicit --verify-command
        # overrides the file, so a file containing that key proves nothing about
        # which value is actually in effect.
        if environment.verifier_from_env_file and environment.env_file is not None:
            notes.append(
                "  note: the verifier command is restored by the env file above, not shown here."
            )
        else:
            notes.append(
                "  note: Verifier command omitted from the displayed resume command; "
                "re-supply it manually."
            )

    try:
        resume_line = render_command(locate + restore, shell=shell_name)
        sessions_line = render_command(
            [Literal("traceh"), Literal("sessions"), Literal("--data-dir"), str(data_dir)],
            shell=shell_name,
        )
    except UnsafeCommandValue:
        # A value that cannot be rendered as one line is not printed as a command
        # at all; the ids are still shown so the session remains findable.
        # Escaped, not raw: the value that made rendering impossible is exactly
        # the value that would otherwise break this explanation too. A data dir
        # containing a newline previously produced a second terminal line here.
        console.write("resume later:")
        console.write(f"  session_id: {escape_for_display(session.session_id)}")
        console.write(f"  data dir:   {escape_for_display(str(data_dir))}")
        console.write(
            "  note: a configuration value contains characters that cannot be shown "
            "safely on one command line, so no command is printed. The values above "
            "are escaped for display."
        )
        return

    label = "PowerShell" if shell_name == "powershell" else "POSIX shell"
    console.write(f"resume later ({label}):")
    console.write(f"  {resume_line}")
    console.write(f"  {sessions_line}")
    for note in notes:
        console.write(note)
    console.write(
        "  note: this restores the session and its non-secret settings; "
        "it is not a complete configuration snapshot."
    )


def _write_seq_note(console: Console, *, timeline: bool) -> None:
    """Explain the event numbers once, before any of them appear."""

    if not timeline:
        return
    for line in _SEQ_NOTE_LINES:
        console.write(line)
