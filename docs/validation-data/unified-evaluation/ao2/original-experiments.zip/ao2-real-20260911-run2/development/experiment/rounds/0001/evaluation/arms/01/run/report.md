# Evaluation: ao2-explicit-development

Run: eff29beb-5a29-456e-9112-d468e010ef30
Task type: retrieval_episode
Measurement complete: True
Assessment complete: False

| Trial | Execution | Assessment | Convergence |
|---|---|---|---|
| be2f9a592409b7200da3d8bc04290d73a0370c260054500a05d21b699c632ffe | completed | pending_review | converged |
| c2f6ed5bf2a200b3cab1c52b654a618fa6097090967ac8f3139ef9c61206c90b | completed | pending_review | converged |
| e71301b6b55965b8245df65dc03ab4a7c871d601571e0f68afc544e8ee6bd00a | completed | pending_review | converged |
| 8e6cd6760c2e65abe41cb0fe47fb5c4285c23c429b5a4cc77a5a056918451ed6 | completed | pending_review | converged |

## Retrieval episodes

Measured: 4/4. Exact answer matches are provisional; final judgments require evidence review.

## Retrieval diagnostics

相关来源候选只定位来源容器；目录不等于正文。派发只证明内容进入请求，不证明模型已理解。
读取回执不证明正文已送达；完整有效搜索片段不需要额外 read。
负例按原查询、字段和分页范围审阅，不把查询无命中当成全库不存在。
observed=已出现，not_observed=本条轨迹未出现，unknown=未知，not_applicable=不适用。
pending_review=待人工审阅；provisional 匹配不是正式评分。

| 题目 ID | 相关来源候选 | 足够证据派发 | 回答评估 | 观测缺口 |
|---|---|---|---|---|
| s-direct | observed | observed | pending_review | evidence-dispatched |
| s-resource | observed | observed | pending_review | evidence-dispatched |
| s-absent | not_applicable | not_applicable | pending_review | negative-scope-review |
| s-english | observed | not_observed | pending_review | candidate-without-evidence |
