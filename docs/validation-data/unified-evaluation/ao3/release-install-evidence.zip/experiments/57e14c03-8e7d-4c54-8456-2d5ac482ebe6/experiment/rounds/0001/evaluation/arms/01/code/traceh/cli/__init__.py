"""TraceHarness command line interface."""
